MAP = {}

MAP.fixScale = 0.5            -- 地图层固定缩放,用于分辨率适应

MAP.TILE_WIDTH        = 56 / MAP.fixScale
MAP.TILE_HEIGHT       = 42 / MAP.fixScale
-- 定义一些预先计算好的中间参数
MAP.TILE_SIDE_LENGTH  = MAP.TILE_WIDTH / math.sqrt(2, 0.5)              --边长
MAP.SIDE_WIDTH_RATIO  = MAP.TILE_SIDE_LENGTH / MAP.TILE_WIDTH           -- 边长与瓦格宽度比值
MAP.SIDE_HEIGHT_RATIO = MAP.TILE_SIDE_LENGTH / MAP.TILE_HEIGHT          -- 边长与瓦格高度比值
MAP.HW_RATIO          = MAP.TILE_HEIGHT / MAP.TILE_WIDTH                -- 瓦格高度与宽度比值
MAP.WH_RATIO          = MAP.TILE_WIDTH / MAP.TILE_HEIGHT                -- 瓦格高度与宽度比值

MAP.GRID_OFFSET_X = 0 -- x方向偏移
MAP.GRID_OFFSET_Y = 30 -- y方向偏移

MAP.GRID_X_WIDTH = 56         -- X方向数量
MAP.GRID_Y_HEIGHT = 44        -- Y方向数量
MAP.GRID_START_X = 24       -- X起始位置
MAP.GRID_START_Y = -22      -- Y起始位置

MAP.BEGIN_MOVE_DIS = 400


-- 地面尺寸。现在是读的图片里的
MAP.groundWidth = 1024
MAP.groundHeight = 768
MAP.minScale = 0
MAP.maxScale = 0

MAP.mapMoving = false --标记正在拖动地图
MAP.buildMoving = false --标记正在拖动建筑
MAP.touchCount = 0
-- 鼠标按下时地图坐标
MAP.movingStartPosX = 0
MAP.movingStartPosY = 0
--鼠标按下坐标
MAP.mouseDownPosX = 0
MAP.mouseDownPosY = 0
--上次鼠标坐标
MAP.lastMousePosX = 0
MAP.lastMousePosY = 0
MAP.canDragMap = true

MAP.setAssembleMode = false
MAP.setAssembleBuilding = nil

MAP.battleFieldWidth = 18
MAP.battleFieldHeight = 40
MAP.battleFieldOffset = 8
MAP.tileMAP1 = {}
MAP.tileMAP2 = {}
MAP.battleFieldTileMap = {}
MAP.inHomeStartX = 31
MAP.inBattleStartX = 21
MAP.startY = -20

-- 驻防区域矩形
MAP.arrangeRec = {beginX=31, beginY=-20, endX=49, endY=20}
-- 驻防区域矩形
MAP.arrangeLandmineRec = {beginX=22, beginY=-20, endX=40, endY=20}
-- 派兵区域
MAP.battleRecs = {{beginX=11, beginY=-20, endX = 21, endY=20}}

MAP.editArrangeMode = false -- 是否布阵模式
MAP.arrangeState = 0        -- 布阵将领的状态，1为基地驻防2为金矿驻防
MAP.ARRANGE_BASE = 1        -- 基地驻防
MAP.ARRANGE_GOLDMINE = 2    -- 金矿驻防

MAP.decorations = {}    -- 装饰物,带有半径，可阻碍士兵，两个之间外切距离必须大于最大单位的直径
MAP.minX = 0            -- 单位行走范围
MAP.maxX = 0
MAP.minY = 0
MAP.maxY = 0
MAP.lockCamera = false

local mapScale = 1.0
local mouseMoved = false
local mouseDowned = false -- 鼠标按下过。防止从其他界面过来误判断为点击
local mouseTargetID = nil
local mouseTargetType = nil -- mouseTarget类型.nil:空, 1:建筑, 2:兵
local mouseBuilding = nil --鼠标位置对应的建筑
local mouseMine = nil -- 地雷 
local mouseUnit = nil
local mouseTeam = nil
-- 单点触控操作相关
local function onTouchsBegin(posX, posY)
    -- logXZL("onTouchsBegin:"..tostring(posX), tostring(posX))
    mouseDowned = true
    mouseMoved = false
    mouseBuilding = nil
    mouseUnit = nil
    mouseTeam = nil
    mouseMine = nil
    MAP.movingStartPosX, MAP.movingStartPosY = MAP.mapLayer:getPosition()
    local mapPosX, mapPosY = MAP.stageToGround(posX, posY)
    mouseTargetID, mouseTargetType = XTP.getTarget(mapPosX, mapPosY)
    if MAP.setAssembleMode == false and mouseTargetID then
        if mouseTargetType == 1 then --建筑
            mouseBuilding = BuildingsManager.getBuildingByID(mouseTargetID)
            if mouseBuilding == nil and BuildingsManager._newBuilding~=nil and mouseTargetID==BuildingsManager._newBuilding._id then
                mouseBuilding = BuildingsManager._newBuilding
            end
            if mouseBuilding then
                ShadersManager.setShader(mouseBuilding._mc, ShaderTypes.HIGH_LIGHT, true)
            end
        -- elseif mouseTargetType == 3 and (SET._mode == CONST.GM_build or SET._mode == CONST.GM_arrange) and MAP.editArrangeMode then -- 地雷
        elseif mouseTargetType == 3 and (SET._mode == CONST.GM_build or SET._mode == CONST.GM_arrange) then -- 地雷
            mouseMine = MinesManager.getMineByID(mouseTargetID)
        -- 兵种点击去掉，改成点击将领头像选择
        -- elseif ((SET._mode == CONST.GM_build or SET._mode == CONST.GM_arrange) and MAP.editArrangeMode) or (SET._mode == CONST.GM_atk and Units._teams[mouseTargetID] ~= Units._selectTeam) then
        --     mouseTeam = Units._teams[mouseTargetID]--Units.getTeam(mouseUnit._generalId,mouseUnit._attacker)          
        end
    end
    MAP.mouseDownPosX = posX
    MAP.mouseDownPosY = posY
    MAP.lastMousePosX = posX
    MAP.lastMousePosY = posY
end
local function onTouchsMove(posX, posY)
--    logXZL("onTouchsMove:"..tostring(MAP.mapLayer:getPosition()))
    if mouseDowned==false then return end
    if not MAP.canDragMap then return end
    if not Tutorial._completed then return end -- 新手引导不允许拖动地图
    if not mouseMoved then --第一次移动
        local deltaX = (posX - MAP.mouseDownPosX)/mapScale
        local deltaY = (posY - MAP.mouseDownPosY)/mapScale
        if (posX - MAP.mouseDownPosX)*(posX - MAP.mouseDownPosX) + (posY - MAP.mouseDownPosY)*(posY - MAP.mouseDownPosY) > MAP.BEGIN_MOVE_DIS then
            if false and SET._mode == CONST.GM_build and mouseBuilding and BASE.checkSelected(mouseBuilding) then --移动建筑
                MAP.startMoveBuild()
                MAP.moveBuilding(deltaX, deltaY)
            elseif (SET._mode == CONST.GM_build or SET._mode == CONST.GM_arrange) and mouseTeam and mouseTeam == Units._selectTeam then --移动部队
                Units.preMoveTeam()         
                Units.moveTeam(deltaX,deltaY)  
                Units.showOtherFoot(0)   
            elseif mouseMine and MinesManager.selectedMine == mouseMine then -- 移动地雷
                MinesManager.preMoveMine()
                MinesManager.moveMine(deltaX, deltaY)
            else --移动地图
                MAP.startMoveMap()
                MAP.mapLayer:setPosition(MAP.movingStartPosX + posX - MAP.mouseDownPosX, MAP.movingStartPosY + posY - MAP.mouseDownPosY)
                MAP.checkEdge()
            end
            mouseMoved = true
        end
    else -- 持续移动
        if MAP.mapMoving then --移动地图
            MAP.mapLayer:setPosition(MAP.movingStartPosX + posX - MAP.mouseDownPosX, MAP.movingStartPosY + posY - MAP.mouseDownPosY)
            MAP.checkEdge()
        elseif MAP.buildMoving then --移动建筑
            local deltaX = (posX - MAP.mouseDownPosX)/mapScale
            local deltaY = (posY - MAP.mouseDownPosY)/mapScale
            MAP.moveBuilding(deltaX, deltaY)
        elseif Units.isMovingTeam then
            local deltaX = (posX - MAP.mouseDownPosX)/mapScale
            local deltaY = (posY - MAP.mouseDownPosY)/mapScale
            Units.moveTeam(deltaX,deltaY)  
        elseif MinesManager.isMovingMine then 
            local deltaX = (posX - MAP.mouseDownPosX)/mapScale
            local deltaY = (posY - MAP.mouseDownPosY)/mapScale
            MinesManager.moveMine(deltaX, deltaY)
        end
    end
    MAP.lastMousePosX = posX
    MAP.lastMousePosY = posY
end
-- cancelClick 用于开始多点触摸时排除点击屏幕
local function onTouchsEnd(posX, posY, cancelClick)
--    logXZL("onTouchsEnd")
    if mouseDowned==false then return end
    if mouseBuilding then
        ShadersManager.setShader(mouseBuilding._mc, ShaderTypes.NORMAL, true)
    end
    if mouseMoved then --移动
        if MAP.mapMoving then --停止移动地图
            MAP.stopMoveMap()
        elseif MAP.buildMoving then --停止移动建筑
            MAP.stopMoveBuild()
        elseif Units.isMovingTeam then
            Units.stopMoveTeam()
            Units.hideOtherFoot()
        elseif MinesManager.isMovingMine then 
            MinesManager.stopMoveMine()
        end
    elseif not cancelClick then  --点击
        if BuildingsManager._newBuilding == nil then --非购买建筑状态
            if MAP.setAssembleMode and MAP.setAssembleBuilding then
                MAP.setAssembleMode = false
                local mapPosX, mapPosY = MAP.stageToGround(posX, posY)
                MAP.setAssembleBuilding:setAssemble(mapPosX,mapPosY)
                MAP.setAssembleBuilding = nil
            elseif mouseBuilding then --点击建筑
                BASE.clickBuilding(mouseBuilding)
--                  MAP.testEffect(posX, posY)
            elseif mouseTeam then -- 点击士兵
                if (SET._mode == CONST.GM_build or SET._mode == CONST.GM_arrange) and MAP.editArrangeMode then
                    BASE.disselectBuilding()
                    Units.Deselect()               
                    mouseTeam:selected()
                    Units._selectTeam = mouseTeam     
                    GeneralData.editAddGeneral = nil
                elseif SET._mode == CONST.GM_atk then
                    if mouseTeam:isMine() then
--                        Units.Deselect()               
--                        mouseTeam:selected()
--                        Units._selectTeam = mouseTeam   
                        if SET._mode == CONST.GM_atk then 
                            -- 派兵或移动
                            local mapPosX, mapPosY = MAP.stageToGround(posX, posY)
                            if Units._selectTeam or Units.selectAllMode then
                                Units.Order(nil,nil,{x=mapPosX,y=mapPosY})
                            elseif BattleField._preSendGeneralID ~= nil then -- 派兵
                                BattleField.SendGeneral(BattleField._preSendGeneralID, mapPosX, mapPosY)
                            end
                        end
                    else
                        Units.Order(nil,mouseTeam)
--                        Units._selectTeam:order(nil,mouseTeam)
                    end
                end
            elseif mouseMine then -- 点击地雷
                Units.Deselect()
                MinesManager.clickMine(mouseMine)
            else --点击地图空地
                if SET._mode == CONST.GM_build or SET._mode == CONST.GM_arrange then
                    BASE.disselectBuilding()
                    MinesManager.deselectMine()
                    if GeneralData.editAddGeneral then -- 驻防派兵
                        local mapPosX, mapPosY = MAP.stageToGround(posX, posY)
                        local gx,gy = MAP.wldToGrid(mapPosX,mapPosY)
                        local canPlace = true
                        local hasQuota = true
                        if gx >= MAP.arrangeRec.beginX and gx <= MAP.arrangeRec.endX and gy >= MAP.arrangeRec.beginY and gy <= MAP.arrangeRec.endY then 
                            canPlace = true
                        end
                        local teamCount = Units.getTeamCount(false)
                        if teamCount >= ConfigManager:getInstance():getPlayerRankItem(UserData.playerInfo._rank).fightGeneralMax then 
                            hasQuota = false
                        end
                        if canPlace and hasQuota then
                            local g = GeneralData.editAddGeneral
                            g._posX = math.floor(mapPosX)
                            g._posY = math.floor(mapPosY)
                            if MAP.arrangeState == MAP.ARRANGE_GOLDMINE then -- 金矿驻防
                                g._mineid = BASE.mineInfo.id
                            elseif MAP.arrangeState == MAP.ARRANGE_BASE then -- 基地驻防
                                g._battleState = GeneralState.BATTLE
                            end
                            g._hideState = false
                            local team = Units.creatTeam(g,false)
                            local editUI = UIManager.curUI
                            editUI:removeGeneralFromList(g)
                            GeneralData.editAddGeneral = nil
                            Units.selectTeam(team)
                        elseif not hasQuota then 
                            POPUPSX.ShowFlyText(Locales.Get("txt_generalLimited"))
                        else
                            POPUPSX.ShowFlyText(Locales.Get("txt_cannotPlace"))
                            -- Units.showOtherFoot(3)
                        end
                    elseif MinesManager.editAddMineData then --驻防放置地雷
                        local mapPosX, mapPosY = MAP.stageToGround(posX, posY)
                        local gridX, gridY = MAP.wldToGrid(mapPosX,mapPosY)
                        local canPlace = MAP.checkBattleFieldPos(gridX, gridY)
                        if canPlace then 
                            local mineData = MinesManager.editAddMineData
                            -- mineData.x = gridX
                            -- mineData.y = gridY
                            -- mineData.placed = true
                            local mine = MinesManager.creatMine(mineData.id, mineData.index, gridX, gridY)
                            -- MinesManager.selectMine(mine) -- 地雷默认选中与驻防界面自动选择地雷有冲突
                            MinesManager.editAddMineData = nil
                            if UIManager.curUIName == UIManager.UI_EDITARRANGE then 
                                UIManager.curUI:update(mineData.index)
                            end
                        else
                            POPUPSX.ShowFlyText(Locales.Get("txt_cannotPlace"))
                        end
                    else
                        local mapPosX, mapPosY = MAP.stageToGround(posX, posY)
                        local gridX, gridY = MAP.wldToGrid(mapPosX,mapPosY)
                        if gridX >= MAP.arrangeRec.beginX and gridX <= MAP.arrangeRec.endX and gridY >= MAP.arrangeRec.beginY and gridY <= MAP.arrangeRec.endY then
                            if Units._selectTeam or Units.selectAllMode then
                                log("Team Move Test: MAP click, Units.Order")
                                Units.Order(nil,nil,{x=mapPosX,y=mapPosY})
                            end
                        end
--                        MAP.testEffect(posX, posY)
                    end
                elseif SET._mode == CONST.GM_visit then -- 派兵，不能移动 -- 再次改为战斗时派兵
                    -- BASE.disselectBuilding()
                    -- local mapPosX, mapPosY = MAP.stageToGround(posX, posY)
                    -- if BattleField._preSendGeneralID ~= nil then -- 派兵
                    --     local gx,gy = MAP.wldToGrid(mapPosX,mapPosY)
                    --     if MAP.checkInBattleRecs(gx, gy) then
                    --         BattleField.SendGeneral(BattleField._preSendGeneralID, mapPosX, mapPosY)
                    --     else
                    --         POPUPSX.ShowFlyText(Locales.Get("txt_outOfSendArea"))
                    --     end
                    -- end
                elseif SET._mode == CONST.GM_atk then -- 战斗时派兵
                    if BASE.baseType ~= CONST.VISIT_RANK then
                        -- 派兵或移动
                        local mapPosX, mapPosY = MAP.stageToGround(posX, posY)
                        if BattleField._preSendGeneralID ~= nil then -- 派兵
                            local gx,gy = MAP.wldToGrid(mapPosX,mapPosY)
                            if MAP.checkInBattleRecs(gx, gy) then
                                BattleField.SendGeneral(BattleField._preSendGeneralID, mapPosX, mapPosY)
                            else
                                POPUPSX.ShowFlyText(Locales.Get("txt_outOfSendArea"))
                            end
                        end
                    end
                    -- if Units._selectTeam or Units.selectAllMode then
                    --     Units.Order(nil,nil,{x=mapPosX,y=mapPosY})
                    -- elseif BattleField._preSendGeneralID ~= nil then -- 派兵
                    --     local gx,gy = MAP.wldToGrid(mapPosX,mapPosY)
                    --     if gx <= MAP.inBattleStartX and gy <= MAP.startY + MAP.battleFieldHeight and gy >= MAP.startY then
                    --         BattleField.SendGeneral(BattleField._preSendGeneralID, mapPosX, mapPosY)
                    --     else
                    --         POPUPSX.ShowFlyText("不在出战范围内")
                    --     end
                    -- end
--                    if Units._selectTeam then
--                        Units._selectTeam:order(nil,nil,{x=mapPosX,y=mapPosY})
--                    end
                end
            end
        end
    end
    mouseDowned = false
end

MAP.isShaking = false
function MAP.shakeMap(time,strength)
    if MAP.isShaking == false then
        MAP.isShaking = true
        local shake = Shaky2D:create(time,strength)
        local cb = function() MAP.isShaking = false end
        local action = cc.Sequence:create(
            shake,
            cc.CallFunc:create(cb) )
        MAP.mapLayer:runAction(action)
    end
end

local function removeEffect(armatureBack,movementType,movementID)
    if movementType == ccs.MovementEventType.start then
        
    elseif movementType == ccs.MovementEventType.complete then
        local node = armatureBack
        if node then
            logLZN1("remove")
            node:removeFromParent()
        end       
    end
end

local count = 2

function MAP.mapScaleAdapter(mapScale)
    if not mapScale then return nil end
    local w, h = director.getScreenSize()
    if w < 1280 and mapScale then 
        mapScale = mapScale * (w + h) / (1280+800)
    end
    return mapScale
end

function MAP.homeCameraMove()
    if MAP.lockCamera then
        director.delayCall(0.2,MAP.homeCameraMove)
    else
        local x,y = MAP.gridToWld(devConfig.cameraStartPos.x,devConfig.cameraStartPos.y)
        MAP.mapScaleMoveTo(cc.p(x,y), MAP.mapScaleAdapter(devConfig.cameraHomeScale), devConfig.cameraSpeed)
    end
end

function MAP.mineCameraMove()
    if MAP.lockCamera then
        director.delayCall(0.2,MAP.mineCameraMove)
    else
        local x,y = MAP.gridToWld(devConfig.cameraMinePos.x,devConfig.cameraMinePos.y)
        MAP.mapScaleMoveTo(cc.p(x,y), MAP.mapScaleAdapter(devConfig.cameraMineScale), devConfig.cameraSpeed)
    end
end

function MAP.rankCameraMove()
    if MAP.lockCamera then
        director.delayCall(0.2,MAP.rankCameraMove)
    else
        local x,y = MAP.gridToWld(devConfig.cameraRankPos.x,devConfig.cameraRankPos.y)
        MAP.mapScaleMoveTo(cc.p(x,y), MAP.mapScaleAdapter(devConfig.cameraRankScale), devConfig.cameraSpeed)
    end
end

function MAP.invadeCameraMove()
    if MAP.lockCamera then
        director.delayCall(0.2,MAP.invadeCameraMove)
    else
        local x,y = MAP.gridToWld(devConfig.cameraInvadePos.x,devConfig.cameraInvadePos.y)
        MAP.mapScaleMoveTo(cc.p(x,y), MAP.mapScaleAdapter(devConfig.cameraInvadeScale), devConfig.cameraSpeed)
    end
end

function MAP.battleCameraMove()
    if MAP.lockCamera then
        director.delayCall(0.2,MAP.battleCameraMove)
    else
        local x,y = MAP.gridToWld(devConfig.cameraBattlePos.x,devConfig.cameraBattlePos.y)
        MAP.mapScaleMoveTo(cc.p(x,y), MAP.mapScaleAdapter(devConfig.cameraBattleScale), devConfig.cameraSpeed)
    end
end

function MAP.battleInvadeCameraMove()
	if MAP.lockCamera then
        director.delayCall(0.2,MAP.battleInvadeCameraMove)
    else
        local x,y = MAP.gridToWld(devConfig.cameraInvadeBattlePos.x,devConfig.cameraInvadeBattlePos.y)
        MAP.mapScaleMoveTo(cc.p(x,y), MAP.mapScaleAdapter(devConfig.cameraInvadeBattleScale), devConfig.cameraSpeed)
    end
end

function MAP.testEffect(posX, posY)
    if not MAP.test then
        MAP.test = myDisplay.newAnimation("tank_hitexplode")
        MAP.test:retain()
        MAP.test:getAnimation():setMovementEventCallFunc(removeEffect)
    else
        MAP.test:removeFromParent()
    end
    MAP.effectLayer:addChild(MAP.test)
    MAP.test:setPosition(posX,posY)
    MAP.test:getAnimation():scheduleUpdate()
    MAP.test:getAnimation():play("bzd",0,0)
--      local mc = myDisplay.newNodeTo(MAP.projectileLayer, NodeType.Layer,{ x=posX, y=posY})
--      local effect2 = myDisplay.newAnimation("paodanhuoguang")
--      mc:addChild(effect2,1)
--      local bullet = myDisplay.newNodeTo(mc, NodeType.Sprite, {filename="fireParticle/bullet1.png"})
--    local unit = myDisplay.newAnimation("soldier_action")
--    unit:getAnimation():play("Idle1", -1, -1)
--    local mc = myDisplay.newNodeTo(MAP.buildingLayer,NodeType.Layer)
--    mc:addChild(unit)
--    local x,y = MAP.gridToWld(31 ,1)
--    mc:setPosition(x,y)
--    local effect = myDisplay.newNodeTo(MAP.effectLayer,NodeType.Layer)
--    effect:setPosition(posx,posy)
--    local emitter1 = cc.ParticleSystemQuad:create("effects/Particles/soldier/qianghuo.plist")
--    local emitter2 = cc.ParticleSystemQuad:create("effects/Particles/soldier/qianghuo.plist")
--    
--    local emitter3 = cc.ParticleSystemQuad:create("effects/Particles/soldier/qianghuo.plist")
--    
--    local emitter4 = cc.ParticleSystemQuad:create("effects/Particles/liehen.plist")
--    emitter4:setBlendAdditive(false)
--    emitter1:setStartSpin(90)
--    emitter1:setEndSpin(90)
--    emitter2:setStartSpin(180)
--    emitter2:setEndSpin(180)
--    emitter3:setStartSpin(60)
--    emitter3:setEndSpin(60)
--    emitter1:setPosition(100,100)
--    emitter2:setPosition(200,100)
--    local batch = cc.ParticleBatchNode:createWithTexture(emitter1:getTexture())
--
--    batch:addChild(emitter1, 0)
--    batch:addChild(emitter2, 0)
--    batch:addChild(emitter3, 0)
--    effect:addChild(batch)
--    
----    effect:addChild(emitter3)
----    effect:addChild(emitter1)
    
--    local effect = myDisplay.newNodeTo(MAP.effectLayer,NodeType.Layer)
--    effect:setPosition(posx,posy)
--    local emitter = myDisplay.newParticle("particles/tuowei.plist", true, false)
--    effect:addChild(emitter)
--    local function dataLoaded(percent)
--        if percent >= 1 then
--            local armature = myDisplay.newAnimation("baozha1")
--            effect:addChild(armature)
--            armature:getAnimation():play("Action0",0,0)
--            effect:setScale(2)
--        end
--    end
--    ccs.ArmatureDataManager:getInstance():addArmatureFileInfoAsync("effects/fireEffects/baozha1.png","effects/fireEffects/baozha1.plist","effects/fireEffects/baozha1.ExportJson", dataLoaded)
end

local finger0 = {down=false, x=0, y=0}
local finger1 = {down=false, x=0, y=0}
local function onTouchsEvent(eventType, touchTab)
--    logXZL("TouchEvent "..tostring(eventType)..":", "touchCount="..#touchTab, tostring(touchTab[1]), tostring(touchTab[2]), tostring(touchTab[3]))
--    logXZL("TouchEvent "..tostring(eventType)..":", tostring(touchTab[1]), tostring(touchTab[2]), tostring(touchTab[3]))
--    addEventListenerWithSceneGraphPriority
--    EventListenerTouchAllAtOnce 
    local pointsCount = #touchTab / 3
    local newTab = {}
    for i=1,pointsCount do --- 遍历去掉0、1以外的触摸事件
        local idIndex = i*3
        if touchTab[idIndex] < 2 then 
            table.insert(newTab, touchTab[idIndex - 2])
            table.insert(newTab, touchTab[idIndex - 1])
            table.insert(newTab, touchTab[idIndex])
        end
    end
    touchTab = newTab

    if #touchTab == 3 then --单个
        if touchTab[3] == 0 then 
            finger0.x = touchTab[1]
            finger0.y = touchTab[2]
            if eventType == "began" then
                finger0.down = true
                if finger1.down == false then -- 单指按下
                    onTouchsBegin(touchTab[1], touchTab[2])
                else -- 第二个手指按下，开始多指缩放
                    MAP.onMultiTouchsBegin()
                end
            elseif eventType == "ended" then
                finger0.down = false
                if finger1.down == false then -- 单指操作抬起
                    onTouchsEnd(touchTab[1], touchTab[2])
                else -- 两指操作抬起第一指
                    MAP.onMultiTouchsEnd()
                end
            elseif eventType == "moved" then
                if finger1.down == false then -- 单指操作时移动
                    onTouchsMove(touchTab[1], touchTab[2])
                else -- 多指操作时移动一指
                    MAP.onMultiTouchsMoved()
                end
            end
        elseif touchTab[3] == 1 then 
            finger1.x = touchTab[1]
            finger1.y = touchTab[2]
            if eventType == "began" then
                finger1.down = true
                if finger0.down == true then  -- 第二个手指按下，开始多指缩放
                    MAP.onMultiTouchsBegin()
                end
            elseif eventType == "ended" then
                finger1.down = false
                if finger0.down == true then -- 两指操作抬起一指
                    MAP.onMultiTouchsEnd()
                end
            elseif eventType == "moved" then
                if finger0.down == true then -- 多指操作时移动一指
                    MAP.onMultiTouchsMoved()
                end
            end
        end
    elseif #touchTab >= 6 then --多个
        if touchTab[3] == 0 then 
            finger0.x = touchTab[1]
            finger0.y = touchTab[2]
        elseif touchTab[3] == 1 then 
            finger1.x = touchTab[1]
            finger1.y = touchTab[2]
        end
        if touchTab[6] == 0 then 
            finger0.x = touchTab[4]
            finger0.y = touchTab[5]
        elseif touchTab[6] == 1 then 
            finger1.x = touchTab[4]
            finger1.y = touchTab[5]
        end
        if eventType == "began" then
            MAP.onMultiTouchsBegin()
        elseif eventType == "ended" then
            MAP.onMultiTouchsEnd()
        elseif eventType == "moved" then
            MAP.onMultiTouchsMoved()
        end
    end
end

function MAP.clear()
    if MAP.groundEffectLayer then 
        MAP.groundEffectLayer:removeAllChildren(true)
    end
    if MAP.midFireLayer then 
        MAP.midFireLayer:removeAllChildren(true)
    end
    if MAP.effectLayer then 
        MAP.effectLayer:removeAllChildren(true)
    end
end

--初始化设置
function MAP.initSetUp(mapLayer)
    for x=devConfig.arrangeLandmineRec.beginX, devConfig.arrangeLandmineRec.endX do
        for y=devConfig.arrangeLandmineRec.beginY, devConfig.arrangeLandmineRec.endY do
            MAP.tileMAP1[x*1000 + y] = 0
        end
    end
    for x=devConfig.arrangeLandmineRec2.beginX, devConfig.arrangeLandmineRec2.endX do
        for y=devConfig.arrangeLandmineRec2.beginY, devConfig.arrangeLandmineRec2.endY do
            MAP.tileMAP2[x*1000 + y] = 0
        end
    end
    MAP.updateRectInfo()
    local screenWidth, screenHeight = director.getScreenSize()
    MAP.BEGIN_MOVE_DIS = math.floor(screenWidth * screenWidth / 2500)
    MAP.mapLayer = myDisplay.newNodeTo(mapLayer, NodeType.Layer) --MAP层
    MAP.groundLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --地面层
    myDisplay.setScaleXY(MAP.groundLayer, devConfig.mapImageScale/MAP.fixScale, devConfig.mapImageScale/MAP.fixScale)
    MAP.gridLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --地图格子层，测试用
    MAP.footLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --脚底层
    MAP.footPrintLayer = myDisplay.newNodeTo(MAP.footLayer, NodeType.Layer) -- 放建筑底板的层
    MAP.footRangeLayer = myDisplay.newNodeTo(MAP.footLayer, NodeType.Layer) -- 放建筑攻击范围的层
    MAP.groundEffectLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --地面特效层
    MAP.bottomLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --建筑底层，如底座、选中的箭头等，地雷也在这一层
	MAP.buildingLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --建筑、地面士兵层
    MAP.lockLayer     = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) -- 建筑锁层
	MAP.buildingOverlayLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) -- 显示建筑血条，名字等等的层	
	MAP.projectileLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --子弹层
    MAP.midFireLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --中层特效层
    MAP.airUnitsLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --飞机层
    MAP.flagLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --放标记的层，比如建筑的选择箭头
    MAP.buildingInfoLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --建筑信息层
    MAP.buildBtnLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --购买按钮层
    MAP.effectLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --顶层特效层
    MAP.topLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --最顶层    
    MAP.tipLayer = myDisplay.newNodeTo(MAP.mapLayer, NodeType.Layer) --顶层tip层
    MAP.groundLayer:registerScriptTouchHandler(onTouchsEvent, true)
    MAP.groundLayer:setTouchEnabled(true)
    MAP.showGround()
    MAP.mapScaleTo(MAP.minScale)
    local x,y = MAP.gridToWld(devConfig.cameraStartPos.x,devConfig.cameraStartPos.y)
    MAP.mapMoveTo(cc.p(x,y))
end

function MAP.checkBattleFieldPos(x,y)
    if MAP.battleFieldTileMap[x*1000 + y] == 1 or not MAP.battleFieldTileMap[x*1000 + y] then
        return false
    else
        return true
    end
end

function MAP.addRectToBattleField(startX,startY,width,height)
    for x=startX, startX + width - 1 do
        for y=startY, startY + height - 1 do
            MAP.battleFieldTileMap[x*1000 + y] = 1
        end
    end
end

function MAP.removeRectFromBattleField(startX,startY,width,height)
    for x=startX, startX + width - 1 do
        for y=startY, startY + height - 1 do
            MAP.battleFieldTileMap[x*1000 + y] = 0
        end
    end
end
function MAP.updateRectInfo()
    if BASE.baseType == CONST.VISIT_Invade or BASE.baseType == CONST.VISIT_SELF or BASE.baseType == CONST.VISIT_Tutorial then -- 入侵战斗或者自己基地，还有新手引导基地
        if devConfig.arrangeRec then 
            MAP.arrangeRec = devConfig.arrangeRec2
        end
        if devConfig.arrangeLandmineRec then 
            MAP.arrangeLandmineRec = devConfig.arrangeLandmineRec2
        end
        if devConfig.battleRecs then 
            MAP.battleRecs = devConfig.battleRecs2
        end
        MAP.battleFieldTileMap = MAP.tileMAP2
    else
        if devConfig.arrangeRec then 
            MAP.arrangeRec = devConfig.arrangeRec
        end
        if devConfig.arrangeLandmineRec then 
            MAP.arrangeLandmineRec = devConfig.arrangeLandmineRec
        end
        if devConfig.battleRecs then 
            MAP.battleRecs = devConfig.battleRecs
        end
        MAP.battleFieldTileMap = MAP.tileMAP1
    end
end

local _curGroundType = MapGroundType.NONE

-- 显示地面背景
function MAP.showGround(groundType)
    if _curGroundType == groundType then
        return
    end
    if _curGroundType == MapGroundType.HOME then
        resource.unloadJpg("map/homeMapL.jpg")
        resource.unloadJpg("map/homeMapR.jpg")
        for i=1, 30 do
            resource.unloadImage(string.format("map/water/shuiliu%d.png", i))
            resource.unloadImage(string.format("map/water/bowen%d.png", i))
        end
        resource.unloadImage("map/water/land1.png")
    elseif _curGroundType == MapGroundType.FIGHT then
        resource.unloadJpg("map/fightMapL.jpg")
        resource.unloadJpg("map/fightMapR.jpg")
        resource.unloadMaskImage("map/water.jpg")
        resource.unloadMaskImage("map/waterrock_01.jpg")
        resource.unloadMaskImage("map/waterrock_03.jpg")
        resource.unloadMaskImage("map/waterrock_04.jpg")
    end
    MAP.groundLayer:removeAllChildren(true)
    groundType = groundType or MapGroundType.HOME
    if groundType == MapGroundType.FIGHT then
        resource.loadJpg("map/fightMapL.jpg")
        MAP.ground1 = myDisplay.newSprite("map/fightMapL.jpg")
        MAP.ground1:setAnchorPoint(0, 0)
        myDisplay.setDisableBlend(MAP.ground1)
        MAP.groundLayer:addChild(MAP.ground1)
        local mainMapSize = MAP.ground1:getContentSize()
        resource.loadJpg("map/fightMapR.jpg")
        MAP.ground2 = myDisplay.newSprite("map/fightMapR.jpg")
        MAP.ground2:setPositionX(mainMapSize.width)
        MAP.ground2:setAnchorPoint(0, 0)
        myDisplay.setDisableBlend(MAP.ground2)
        MAP.groundLayer:addChild(MAP.ground2)
        MAP.groundWidth = (mainMapSize.width + MAP.ground2:getContentSize().width) * MAP.groundLayer:getScaleX()
        MAP.groundHeight = mainMapSize.height * MAP.groundLayer:getScaleY()
        resource.loadMaskImage("map/water.jpg")
        local water = myDisplay.newSprite("map/water.jpg")
        water:setPosition(MAP.ground1:getContentSize().width + MAP.ground2:getContentSize().width, 0)
        water:setAnchorPoint(1, 0)
        MAP.groundLayer:addChild(water)
        if device.platform == "ios" or device.platform == "windows" then
            local normalTexture = resource.loadImage("map/waterNormal.jpg")
            normalTexture:setTexParameters(gl.LINEAR, gl.LINEAR, gl.REPEAT, gl.REPEAT)
            local shader = ShadersManager.getShader(ShaderTypes.WARTER)
            local shaderState = cc.GLProgramState:create(shader)
            shaderState:setUniformTexture("u_normalMap", normalTexture:getName())
            ShadersManager.setShaderState(water, shaderState)
        elseif device.platform == "android" then -- android手机可能对多重纹理采样支持不好
            local shader = ShadersManager.getShader(ShaderTypes.WARTER2)
            local shaderState = cc.GLProgramState:create(shader)
            ShadersManager.setShaderState(water, shaderState)
        end
        local rockPositions = {{26,-52},{499,313},{848,512},{958,747}}
        local rockImageWidth = 1105
        local mapWidth = MAP.ground1:getContentSize().width + MAP.ground2:getContentSize().width
        for i=1, #rockPositions do
            local waterRock
            if i == 2 then
                resource.loadMaskImage("map/waterrock_01.jpg")
                waterRock = myDisplay.newSprite("map/waterrock_01.jpg")
            else
                local imageName = string.format("map/waterrock_0%d.jpg", i)
                resource.loadMaskImage(imageName)
                waterRock = myDisplay.newSprite(imageName)
            end
            local x = mapWidth - rockImageWidth + rockPositions[i][1]
            local y = rockPositions[i][2]
            waterRock:setPosition(x, y)
            waterRock:setAnchorPoint(0, 0)
            MAP.groundLayer:addChild(waterRock)
        end
    elseif groundType == MapGroundType.HOME then
        resource.loadJpg("map/homeMapL.jpg")
    	MAP.ground1 = myDisplay.newSprite("map/homeMapL.jpg")
    	MAP.ground1:setAnchorPoint(0, 0)
        myDisplay.setDisableBlend(MAP.ground1)
        MAP.groundLayer:addChild(MAP.ground1)
        local mainMapSize = MAP.ground1:getContentSize()
        resource.loadJpg("map/homeMapR.jpg")
    	MAP.ground2 = myDisplay.newSprite("map/homeMapR.jpg")
        MAP.ground2:setPositionX(mainMapSize.width)
    	MAP.ground2:setAnchorPoint(0, 0)
        MAP.ground2:setLocalZOrder(-1)
        myDisplay.setDisableBlend(MAP.ground2)
        MAP.groundLayer:addChild(MAP.ground2)
        MAP.groundWidth = (mainMapSize.width + MAP.ground2:getContentSize().width) * MAP.groundLayer:getScaleX()
        MAP.groundHeight = mainMapSize.height * MAP.groundLayer:getScaleY()

        -- local water = AnimationManager.createAnimation("map/water/shuiliu", 30)
        -- water._sprite:setPosition(297.9, 1385.5)
        -- -- water._sprite:setScale(2)
        -- water._sprite:setAnchorPoint(0, 0)
        -- myDisplay.setAdditiveBlend(water._sprite)
        -- MAP.ground1:addChild(water._sprite)
        
        

        local shuiliuArr = {}
        local bowenArr = {}
        local frame
        for i=1, 30 do
            frame = cc.SpriteFrameCache:getInstance():addSpriteFrameWithPath(string.format("map/water/shuiliu%d.png", i))
            table.insert(shuiliuArr, frame)
            frame = cc.SpriteFrameCache:getInstance():addSpriteFrameWithPath(string.format("map/water/bowen%d.png", i))
            table.insert(bowenArr, frame)
        end
        local animation = cc.Animation:createWithSpriteFrames(shuiliuArr, 0.033, 1)
        local action = cc.RepeatForever:create(cc.Animate:create(animation))
        local water = myDisplay.newNodeTo(MAP.ground1, NodeType.Sprite, "map/water/shuiliu1.png")
        water:runAction(action)
        water:setPosition(297.9, 1385.5)
        water:setAnchorPoint(0, 0)

        resource.loadImage("map/water/land1.png")
        local land1 = myDisplay.newNodeTo(MAP.ground1, NodeType.Sprite, "map/water/land1.png")
        land1:setPosition(224.2, 1702.8)
        land1:setAnchorPoint(0, 0)
        -- land1:setScale(2)

        animation = cc.Animation:createWithSpriteFrames(bowenArr, 0.033, 1)
        -- 水波纹添加
        local ripplePositions = {1125, 2238, 714, 1750, 841, 1574, 1117, 1321, 2016, 643, 2424, 309, 2510, 98}
        for i=1, math.floor(#ripplePositions/2) do
            local x = ripplePositions[i * 2 - 1] * 0.75576
            local y = ripplePositions[ i * 2] * 0.75576
            -- local ripple = AnimationManager.createAnimation("map/water/bowen", 30)
            -- ripple._sprite:setPosition(x, y)
            -- ripple._sprite:setAnchorPoint(0, 0)
            -- ripple._sprite:setOpacity(75)
            -- -- ripple._sprite:setScale(1.5)
            -- -- myDisplay.setAdditiveBlend(ripple._sprite)
            -- MAP.ground1:addChild(ripple._sprite)
            local water = myDisplay.newNodeTo(MAP.ground1, NodeType.Sprite, "map/water/bowen1.png")
            action = cc.RepeatForever:create(cc.Animate:create(animation))
            water:runAction(action)
            water:setPosition(x, y)
            myDisplay.setAdditiveBlend(water)
            -- water:setOpacity(75)
            water:setAnchorPoint(0, 0)
        end
    else
        logError("groundType is illegal")
    end
    local screenWidth, screenHeight = director.getScreenSize()
    local minScaleX = screenWidth / MAP.groundWidth
    local minScaleY = screenHeight / MAP.groundHeight
    if minScaleX > minScaleY then 
        MAP.minScale = minScaleX
    else 
        MAP.minScale = minScaleY
    end

    MAP.maxScale = 1
end

-- 进入建筑移动模式
function MAP.startMoveBuild()
    BASE.preMoveBuildings()
    MAP.buildMoving = true
end
function MAP.moveBuilding(deltaX, deltaY)
    -- local targetX, targetY = MAP.alignWldToGrid(buildOldPosX+deltaX, buildOldPosY+deltaY)
    BASE.moveBuildings(deltaX, deltaY)
    -- BASE.selectedBuilding:SetPosition(targetX, targetY)
    -- BuildingInfoPopup.setPosition(targetX, targetY)
end
-- 结束建筑移动
function MAP.stopMoveBuild()
    BASE.stopMoveBuildings()
    MAP.buildMoving = false
end
-- 进入地图移动模式
function MAP.startMoveMap()
	MAP.mapMoving = true
end
-- 结束地图移动
function MAP.stopMoveMap()
	MAP.mapMoving = false
end
-- 检查地图边缘出界
function MAP.checkEdge()
	local posX, posY = MAP.mapLayer:getPosition()
	local screenWidth, screenHeight = director.getScreenSize()
--	logXZL("checkEdge:"..tostring(MAP.groundWidth), tostring(MAP.groundHeight))
	if posX > 0 then posX = 0 end
	if posY > 0 then posY = 0 end
	if (posX + MAP.groundWidth*mapScale) < screenWidth then posX = screenWidth - MAP.groundWidth*mapScale end
	if (posY + MAP.groundHeight*mapScale) < screenHeight then posY = screenHeight - MAP.groundHeight*mapScale end
	MAP.mapLayer:setPosition(posX, posY)
end

-- 获取当前场景的中心点位置
function MAP.getCenterPos()
    local screenWidth, screenHeight = director.getScreenSize()
    local centerScreen = cc.p(screenWidth*0.5, screenHeight*0.5)
    local targetPos = MAP.mapLayer:convertToNodeSpace(centerScreen)
    return targetPos
end

-- 场景缩放
-- @param targetScale 目标比例
-- @param targetPos 缩放时保证此点位于屏幕中央
function MAP.mapScaleTo(targetScale, targetPos, time, callback)
    if not targetPos then -- 默认以屏幕中央进行缩放
        local screenWidth, screenHeight = director.getScreenSize()
        local centerScreen = cc.p(screenWidth*0.5, screenHeight*0.5)
        targetPos = MAP.mapLayer:convertToNodeSpace(centerScreen)
    end
    time = time or 0
    if MAP._scaleTimer then
        director.destroyTimer(MAP._scaleTimer)
        MAP._scaleTimer = nil
        MAP.groundLayer:setTouchEnabled(true)
    end
    if time <= 0 then
        mapScale = targetScale
        MAP.mapLayer:setScale(targetScale)
        MAP.mapMoveTo(targetPos)
        if callback then
            callback()
        end
    else
        local oldScale = MAP.mapLayer:getScale()
        local timeCounter = 0
        MAP.groundLayer:setTouchEnabled(false)
        local scaleFunc = function(dt)
            timeCounter = timeCounter + dt
            local pct = timeCounter / time
            if pct > 1 then 
                pct = 1
            end
            local curScale = oldScale + pct * (targetScale - oldScale)
            mapScale = curScale
            MAP.mapLayer:setScale(curScale)
            MAP.mapMoveTo(targetPos)
            if timeCounter >= time then
                director.destroyTimer(MAP._scaleTimer)
                MAP._scaleTimer = nil
                MAP.groundLayer:setTouchEnabled(true)
                if callback then
                    callback()
                end
            end
        end
        MAP._scaleTimer = director.createTimer(scaleFunc)
    end
    if UIManager.curUIName == UIManager.UI_MAIN then 
        UIManager.curUI:updateUserData()
    end
end

-- 镜头移动到地图上的某个点:targetPos地图坐标，例如建筑的x,y
function MAP.mapMoveTo(targetPos, time, callback)
    if not time then time = 0 end
    local screenWidth, screenHeight = director.getScreenSize()
    local posX = screenWidth/2 - targetPos.x*mapScale
    local posY = screenHeight/2 - targetPos.y*mapScale
    if posX > 0 then posX = 0 end
    if posY > 0 then posY = 0 end
    if (posX + MAP.groundWidth*mapScale) < screenWidth then posX = screenWidth - MAP.groundWidth*mapScale end
    if (posY + MAP.groundHeight*mapScale) < screenHeight then posY = screenHeight - MAP.groundHeight*mapScale end
    MAP.groundLayer:setTouchEnabled(false)
    local moveCompleteHandler = function ()
        MAP.groundLayer:setTouchEnabled(true)
        if callback ~= nil then 
            callback()
        end
    end
    if time > 0 then
        CCTween.CCMoveTo(MAP.mapLayer, time, {x=posX, y=posY}, moveCompleteHandler)
    else
        MAP.mapLayer:setPosition(posX, posY)
        moveCompleteHandler()
    end
end

-- 镜头缩放并移动到某个点
function MAP.mapScaleMoveTo(targetPos, targetScale, time, callback)
    time = time or 0
    local screenWidth, screenHeight = director.getScreenSize()
    local posX = screenWidth/2 - targetPos.x*targetScale
    local posY = screenHeight/2 - targetPos.y*targetScale
    if posX > 0 then posX = 0 end
    if posY > 0 then posY = 0 end
    if (posX + MAP.groundWidth*targetScale) < screenWidth then posX = screenWidth - MAP.groundWidth*targetScale end
    if (posY + MAP.groundHeight*targetScale) < screenHeight then posY = screenHeight - MAP.groundHeight*targetScale end
    MAP.mapLayer:stopAllActions()
    MAP.groundLayer:setTouchEnabled(false)
    local moveCompleteHandler = function ()
        MAP.groundLayer:setTouchEnabled(true)
        mapScale = targetScale
        if callback ~= nil then callback() end
    end
    local moveToAction = cc.MoveTo:create(time, cc.p(posX, posY))
    local scaleToAction = cc.ScaleTo:create(time, targetScale)
    local spawnAction = cc.Spawn:create(moveToAction, scaleToAction)
    local callBackAction = cc.CallFunc:create(moveCompleteHandler)
    local finalAction = cc.Sequence:create(spawnAction, callBackAction)
    MAP.mapLayer:runAction(finalAction)
end

local BUG_FIX_Y = 0 --因为convertToNodeSpace偏移bug的校准
function MAP.stageToGround(x, y)
    local pos = MAP.gridLayer:convertToNodeSpace(cc.p(x, y))
    return pos.x, pos.y - BUG_FIX_Y
    -- return (x-posX)/mapScale, (y-posY)/mapScale
end

-- 地图坐标转换为格子坐标，格子坐标系为东北方向为正x方向，西北方向为正y方向，(0, 0)与地图的(0, 0)重合,结果为整型
function MAP.wldToGrid(worldX, worldY, noOffset)
    local x, y = MAP.wldToGridPrecise(worldX, worldY, noOffset)
    x = math.floor(x)
    y = math.floor(y)
    return x, y
end

-- 同上，但精确计算
function MAP.wldToGridPrecise(worldX, worldY, noOffset)
    if not noOffset then
        worldX = worldX - MAP.GRID_OFFSET_X
        worldY = worldY - MAP.GRID_OFFSET_Y
    end
    local x = worldX / MAP.TILE_WIDTH + worldY / MAP.TILE_HEIGHT
    local y = -worldX / MAP.TILE_WIDTH + worldY / MAP.TILE_HEIGHT
    return x, y
end

-- 将该世界坐标转换为和格子对齐的坐标
function MAP.alignWldToGrid(wldX, wldY, noOffset)
    local x, y = MAP.wldToGrid(wldX, wldY, noOffset)
    x, y = MAP.gridToWld(x, y, noOffset)
    return x, y
end

-- 格子坐标转换为世界坐标,此坐标为格子的底部尖角坐标
function MAP.gridToWld(gridX, gridY, noOffset)
    local x = ((gridX - gridY) * MAP.TILE_WIDTH * 0.5)
    local y = ((gridX + gridY) * MAP.TILE_HEIGHT * 0.5)
    if not noOffset then
        x = x + MAP.GRID_OFFSET_X
        y = y + MAP.GRID_OFFSET_Y
    end
    return x, y
end

function MAP.gridCenterToWld(gridX, gridY, noOffset)
    local x, y = MAP.gridToWld(gridX, gridY, noOffset)
    return x, y + MAP.TILE_HEIGHT * 0.5
end

-- 斜角转格子坐标，结果为整型
function MAP.isoToGrid(isoX, isoY, noOffset)
    local x, y = MAP.isoToGridPrecise(isoX, isoY, noOffset)
    x = math.floor(x)
    y = math.floor(y)
    return x, y
end

-- 同上，但精确计算
function MAP.isoToGridPrecise(isoX, isoY)
    local x = isoX / MAP.TILE_SIDE_LENGTH
    local y = isoY / MAP.TILE_SIDE_LENGTH
    return x, y
end

-- 格子坐标转斜角坐标
function MAP.gridToISO(gridX, gridY)
    local x = gridX * MAP.TILE_SIDE_LENGTH
    local y = gridY * MAP.TILE_SIDE_LENGTH
    return x, y
end

-- 地图坐标转换为斜坐标,基向量单位为像素
function MAP.wldToISO(worldX, worldY)
    worldX = worldX - MAP.GRID_OFFSET_X
    worldY = worldY - MAP.GRID_OFFSET_Y
    local x = worldX * MAP.SIDE_WIDTH_RATIO + worldY * MAP.SIDE_HEIGHT_RATIO
    local y = -worldX * MAP.SIDE_WIDTH_RATIO + worldY * MAP.SIDE_HEIGHT_RATIO
    return x, y
end

-- 斜角坐标转世界坐标
function MAP.isoToWld(isoX, isoY)
    local x, y = MAP.isoToGridPrecise(isoX, isoY)
    x, y = MAP.gridToWld(x, y)
    x = x + MAP.GRID_OFFSET_X
    y = y + MAP.GRID_OFFSET_Y
    return x, y
end

-- 世界坐标在斜坐标系中的距离计算                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
function MAP.isoDistanceOfWldPos(x1, y1, x2, y2)
    -- local x = ((x1*MAP.HW_RATIO)+y1) - ((x2*MAP.HW_RATIO)+y2)
    -- local y = (y1-(x1*MAP.HW_RATIO)) - (y2-(x2*MAP.HW_RATIO))
    local x = x1 - x2
    local y = (y1 - y2) * MAP.WH_RATIO
    return math.sqrt(x*x + y*y)
end

-- 世界坐标系转俯视坐标系
-- 用于简单计算射程，角度等,不在斜坐标中计算
function MAP.wldToOverlook(wldX, wldY)
    worldX = worldX - MAP.GRID_OFFSET_X
    worldY = worldY - MAP.GRID_OFFSET_Y
    return wldX, wldY * MAP.HW_RATIO
end

function MAP.overlookToWld(ox, oy)
    return ox, oy * MAP.WH_RATIO
end

-- 建筑移动时适用景深排序，当多个这样的建筑同时存在时也能保持他们的相对景深
local movingZ = 10000000
function MAP.SetTopZOrder(v, x, y)
    myDisplay.setZOrder(v, -y*1000-x+movingZ)
end

-- 建筑兵种正常景深排序使用此方法
function MAP.SetZOrder(v, x, y)
    myDisplay.setZOrder(v, -y*1000-x)
end

-- 将其放在最顶层，如果有多个物体采用此函数设置景深，则无法保证其相对景深，使用SetTopZOrder替代
local bigNum = 100000000
function MAP.SetDepthAsTop(v)
    if v and v._mc then
        MAP.SetDepthAsTopB(v._mc)
    end
end

function MAP.SetDepthAsTopB(v)
    myDisplay.setZOrder(v, bigNum)
    bigNum = bigNum + 1
end

function MAP.clearSelectUnit()
    mouseUnit = nil
end

-- 将其放置在底层，当多个这样的建筑同时存在时也能保持他们的相对景深
local bottomMovingZ = -10000000
function MAP.SetBottomZOrder(v, x, y)
    myDisplay.setZOrder(v, -y*1000-x+bottomMovingZ)
end
-- 判断是否在放兵区域内
function MAP.checkInBattleRecs(gridX, gridY)
    for i,rec in ipairs(MAP.battleRecs) do
        if gridX >= rec.beginX and gridX <= rec.endX and gridY >= rec.beginY and gridY <= rec.endY then 
            return true
        end
    end
    return false
end

-- 获取是否与障碍物或边界碰撞，并返回反力向量
function MAP.getIsCollide(pos, radius)
    local isCollide = false
    local collideVec = nil
    for _, decoration in MAP.decorations do
        if cc.pGetDistanceSQ(pos, decoration._pos) < radius + decoration._radius then
            isCollide = true
            collideVec = cc.pSub(pos, decoration._pos)
            break
        end
    end
    return isCollide, collideVec
end

------------------------------------------- 多点触摸相关 --------------------------------------------------------------------------
local beginDis = 0
local beginScale = 0
local beginFinger0_X = 0
local beginFinger0_Y = 0
local beginFinger1_X = 0
local beginFinger1_Y = 0
local beginFinger0MapPos = nil -- 缩放时保证一点位置不变
local curDis = 0
function MAP.onMultiTouchsBegin()
    if not Tutorial._completed then return end -- 新手引导过程中屏蔽多指缩放
    onTouchsEnd(finger0.x, finger0.y, true)
    beginFinger0_X = finger0.x
    beginFinger0_Y = finger0.y
    beginFinger1_X = finger1.x
    beginFinger1_Y = finger1.y
    local offsetX = beginFinger0_X - beginFinger1_X
    local offsetY = beginFinger0_Y - beginFinger1_Y
    beginDis = math.sqrt(offsetX*offsetX + offsetY*offsetY)
    beginScale = mapScale
    beginFinger0MapPos = MAP.mapLayer:convertToNodeSpace(cc.p(finger0.x, finger0.y))
end
function MAP.onMultiTouchsMoved()
    if not Tutorial._completed then return end -- 新手引导过程中屏蔽多指缩放
    MAP.touchCount = 2
    local offsetX = finger0.x - finger1.x
    local offsetY = finger0.y - finger1.y
    if beginDis > 0 then 
        curDis = math.sqrt(offsetX*offsetX + offsetY*offsetY)
        if curDis > 0 then 
            local targetScale = curDis / beginDis * beginScale
            if targetScale < MAP.minScale then 
                targetScale = MAP.minScale 
            end
            if targetScale > MAP.maxScale then 
                targetScale = MAP.maxScale
            end
            MAP.mapLayer:setScale(targetScale)
            mapScale = targetScale
            local centerPosNew = MAP.mapLayer:convertToNodeSpace(cc.p(finger0.x, finger0.y))
            local disX = centerPosNew.x - beginFinger0MapPos.x
            local disY = centerPosNew.y - beginFinger0MapPos.y
            local posX, posY = MAP.mapLayer:getPosition()
            posX = posX + disX * mapScale
            posY = posY + disY * mapScale
            local screenWidth, screenHeight = director.getScreenSize()
            if posX > 0 then posX = 0 end
            if posY > 0 then posY = 0 end
            if (posX + MAP.groundWidth*mapScale) < screenWidth then posX = screenWidth - MAP.groundWidth*mapScale end
            if (posY + MAP.groundHeight*mapScale) < screenHeight then posY = screenHeight - MAP.groundHeight*mapScale end
            MAP.mapLayer:setPosition(posX, posY)
            if UIManager.curUIName == UIManager.UI_MAIN then 
                UIManager.curUI:updateUserData()
            end
            local finger1Point = MAP.mapLayer:convertToNodeSpace(cc.p(finger1.x, finger1.y))
            offsetX = centerPosNew.x - finger1Point.x
            offsetY = centerPosNew.y - finger1Point.y
            local mapDis = math.sqrt(offsetX*offsetX + offsetY*offsetY)
        end
    end
end
function MAP.onMultiTouchsEnd()
    if not Tutorial._completed then return end -- 新手引导过程中屏蔽多指缩放
    beginDis = 0
end

function MAP.getMapScale()
    return mapScale
end
function MAP.hideMap()
    MAP.mapLayer:setVisible(false)
end
function MAP.showMap()
    MAP.mapLayer:setVisible(true)
end
-- 是否可以屏幕拖动
function MAP.setMapDragState(value)
    if MAP.canDragMap == value then return end
    if value then 
        MAP.canDragMap = true
    else
        MAP.canDragMap = false
        onTouchsEnd(MAP.lastMousePosX, MAP.lastMousePosY,  true)
    end
end
-- 显示圆形派兵区域，新手引导用
function MAP.showSendArmyArea(pos)
    if not MAP.armyArea then 
        MAP.armyArea = myDisplay.newNodeTo(MAP.gridLayer, NodeType.Sprite, "ui/guide_circle.png")
        -- MAP.armyArea:setScaleX(8)
        MAP.armyArea:setScaleY(0.5)
    end
    MAP.armyArea:setPosition(MAP.gridToWld(pos.x, pos.y))
end
function MAP.removeSendArmyArea()
    if MAP.armyArea then 
        myDisplay.removeNode(MAP.armyArea)
        MAP.armyArea = nil
    end
end------------------------------ 多点测试 ---------------------------------------------
MAP.multiTouchTestOn = false
function MAP.beginMultiTouchTest()
    require("app.base.MultiTouchTest")
    MAP.multiTouchTestOn = true
    MultiTouchTest.beginTest(onTouchsEvent)
end
function MAP.endMultiTouchTest()
    if MultiTouchTest then 
        MAP.multiTouchTestOn = false
        MultiTouchTest.endTest()
        package.loaded["app.base.MultiTouchTest"] = nil
    end
end

-- 由于可能对部分动画统一减少分辨率，为了保持在屏幕上的相对大小，实现统一函数进行缩放
local fixScaleFactor = 2
function MAP.scaleAnimation(mc)
    if mc then
        myDisplay.scaleByXY(mc, fixScaleFactor, fixScaleFactor)
    end
end