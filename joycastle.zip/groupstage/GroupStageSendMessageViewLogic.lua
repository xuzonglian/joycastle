
--组队副本 一键喊话
GroupStageSendMessageViewLogic = class("GroupStageSendMessageViewLogic",ViewBaseLogic)
-------------------------------------------------------
local MAX_WORLD_LEN = 50
function GroupStageSendMessageViewLogic:ctor()
	self.CCS_FILE_NAME_PREFIX = Config.CSB_FILE_DIR_1
	self.csbName = "zuduifuben_yijianhanhua"
	self.fullScene = false
	self.viewLevel = SceneHelper.LAYER_TYPE.SECOND_LYAER
end

function GroupStageSendMessageViewLogic:onOpen()
	self:initUI()
end

function GroupStageSendMessageViewLogic:initUI()
	self.Panel_1 = self:getChildByName("Panel_1")
	self.btn_close = self.Panel_1:getChildByName("btn_close")
	self.txt_title = self.Panel_1:getChildByName("txt_title")
	self.txt_xuanze = self.Panel_1:getChildByName("txt_xuanze")
	self.CheckBox_shijie = self.Panel_1:getChildByName("CheckBox_shijie")
	self.txt_shijie = self.Panel_1:getChildByName("txt_shijie")
	self.CheckBox_juntuan = self.Panel_1:getChildByName("CheckBox_juntuan")
	self.txt_juntuan = self.Panel_1:getChildByName("txt_juntuan")
	self.txt_tip = self.Panel_1:getChildByName("txt_tip")
	self.txt_input = self.Panel_1:getChildByName("txt_input")
	self.btn_quxiao = self.Panel_1:getChildByName("btn_quxiao")
	self.btnTxt_quxiao = self.btn_quxiao:getChildByName("txt")
	self.btn_queding = self.Panel_1:getChildByName("btn_queding")
	self.btnTxt_queding = self.btn_queding:getChildByName("txt")

	Util.setTextString(self.txt_title, LanUtil.getLan("GroupStageTxt_32"))
	Util.setTextString(self.txt_xuanze, LanUtil.getLan("GroupStageTxt_33"))
	Util.setTextString(self.txt_shijie, LanUtil.getLan("GroupStageTxt_34"))
	Util.setTextString(self.txt_juntuan, LanUtil.getLan("GroupStageTxt_35"))
	Util.setTextString(self.txt_tip, LanUtil.getLan("GroupStageTxt_36"))
	Util.setTextString(self.btnTxt_quxiao, LanUtil.getLan("GroupStageTxt_10"))
	Util.setTextString(self.btnTxt_queding, LanUtil.getLan("TXT_fasong"))
	Util.setTextString(self.txt_input, LanUtil.getLan("GroupStageTxt_36"))


	self.editBoxInput = CCX.transformAsEditBox(self.txt_input)
	self.editBoxInput:setMaxLength(MAX_WORLD_LEN)
	if GroupStageData.lastMessageText then
		self.editBoxInput:setText(GroupStageData.lastMessageText)
	end
	-- self.editBoxInput:setPlaceHolder("")

	self.editBoxInput:registerScriptEditBoxHandler(self:getOnInputText())

	self:addClickEventListener(self.btn_close, function ()
		self:closeView()
	end)

	self.CheckBox_shijie:addEventListener(function ()
		self:setTargetType(1)
	end)
	self.CheckBox_juntuan:addEventListener(function ()
		self:setTargetType(2)
	end)

	self:addClickEventListener(self.btn_quxiao, function ()
		self:closeView()
	end)
	self:addClickEventListener(self.btn_queding, function ()
		local teamself = GroupStageData.teamself
		if not teamself then 
			self:closeView()
			return
		end
		local textStr = self.editBoxInput:getText()
		if textStr == "" then 
			Global.showTips(LanUtil.getLan("GroupStageTxt_53"))
			return
		end
		if string.len(textStr) > 90 then
			Global.showTips(LanUtil.getLan("GroupStageTxt_37"))
			return
		end
		textStr = SensitiveWordManager.filterChar(textStr)
		GroupStageData.lastMessageText = textStr
		if self._targetType == 1 then 
			local curTime = HeartBeatManager.getTime()
			local lastMessageTime1 = GroupStageData.lastMessageTime1 or 0
			if curTime - lastMessageTime1 > 30 then 
				GroupStageData.lastMessageTime1 = curTime
				NetMessageSystem.sendRequest(ID_DceChat, {type=ChatData.LABEL.GroupStage_MSGWorld, content=textStr, indexteam=teamself.indexteam, idgroupstage=teamself.idstage}, true )
				self:closeView()
			else
				Global.showTips(LanUtil.getLan("GroupStageTxt_50"))
			end
		else
			local curTime = HeartBeatManager.getTime()
			local lastMessageTime2 = GroupStageData.lastMessageTime2 or 0
			if curTime - lastMessageTime2 > 30 then 
				GroupStageData.lastMessageTime2 = curTime
				NetMessageSystem.sendRequest(ID_DceChat, {type=ChatData.LABEL.GroupStage_MSGGuild, content=textStr, indexteam=teamself.indexteam, idgroupstage=teamself.idstage}, true )
				self:closeView()
			else
				Global.showTips(LanUtil.getLan("GroupStageTxt_50"))
			end
		end
	end)

	self:updateInfo()
end

function GroupStageSendMessageViewLogic:getOnInputText()
	return function(eventType, sender)
		if  eventType == "began" then -- 弹出键盘开始输入
		elseif eventType == "changed" then -- 修改文本
			self:adjustInputContent()
		elseif eventType == "ended" then -- 输入结束
			self:adjustInputContent()
		elseif eventType == "return" then -- 返回
			self:adjustInputContent()
		end
	end
end

function GroupStageSendMessageViewLogic:adjustInputContent()
	local textStr = self.editBoxInput:getText()
	if string.len(textStr) > 90 then
		Global.showTips(LanUtil.getLan("GroupStageTxt_37"))
		return
	end
end

function GroupStageSendMessageViewLogic:updateInfo()
	self:setTargetType(GroupStageData.lastMessageType or 1)
end

-- 发送目标
function GroupStageSendMessageViewLogic:setTargetType(_type)
	self._targetType = _type or 1
	GroupStageData.lastMessageType = self._targetType
	if self._targetType == 1 then 
		self.CheckBox_shijie:setSelected(true)
		self.CheckBox_juntuan:setSelected(false)
	else
		self.CheckBox_shijie:setSelected(false)
		self.CheckBox_juntuan:setSelected(true)
	end
end


function GroupStageSendMessageViewLogic:onClose()
end

-- -- 战斗力变化
-- local function evt_LeagueDataUpdate(self)
-- end

-- function GroupStageSendMessageViewLogic:initEventListener()
-- 	self:registerEventListener(EventType.LeagueDataUpdate, evt_LeagueDataUpdate)
-- end
