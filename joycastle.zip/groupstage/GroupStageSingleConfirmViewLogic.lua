
--组队副本 单人副本进入确认
GroupStageSingleConfirmViewLogic = class("GroupStageSingleConfirmViewLogic",ViewBaseLogic)
-------------------------------------------------------
function GroupStageSingleConfirmViewLogic:ctor(callback)
	self.CCS_FILE_NAME_PREFIX = Config.CSB_FILE_DIR_1
	self.csbName = "zuduifuben_jinru"
	self.fullScene = false
	self.viewLevel = SceneHelper.LAYER_TYPE.SECOND_LYAER

	self._callback = callback
end

function GroupStageSingleConfirmViewLogic:onOpen()
	self:initUI()
end

function GroupStageSingleConfirmViewLogic:initUI()
	self.Panel_1 = self:getView():getChildByName("Panel_1")

	self.txt_title = self.Panel_1:getChildByName("txt_title")
	self.btn_close = self.Panel_1:getChildByName("btn_close")
	self.btn_kaiqi = self.Panel_1:getChildByName("btn_kaiqi")
	self.btnTxt_kaiqi = self.btn_kaiqi:getChildByName("txt")
	self.CheckBox_1 = self.Panel_1:getChildByName("CheckBox_1")
	self.txt_CheckBox = self.Panel_1:getChildByName("txt_CheckBox")
	self.txt_miaoshu = self.Panel_1:getChildByName("txt_miaoshu")

	Util.setTextString(self.txt_title, LanUtil.getLan("GroupStageTxt_46"))
	Util.setTextString(self.btnTxt_kaiqi, LanUtil.getLan("TXT_COMMON_APPLY"))
	Util.setTextString(self.txt_miaoshu, LanUtil.getLan("GroupStageTxt_47"))
	Util.setTextString(self.txt_CheckBox, LanUtil.getLan("GroupStageTxt_48"))


	self:addClickEventListener(self.btn_close, function ()
		self:closeView()
	end)

	self:addClickEventListener(self.btn_kaiqi, function ()
		self:closeView(function ()
			if self._callback then 
				self._callback()
			end
		end)
	end)

	self.CheckBox_1:setSelected(false)

	self.CheckBox_1:addEventListener(function ()
		if self.CheckBox_1:isSelected() then 
			GroupStageData._confirmOff = true
		else
			GroupStageData._confirmOff = false
		end
	end)
end



function GroupStageSingleConfirmViewLogic:onClose()
end
