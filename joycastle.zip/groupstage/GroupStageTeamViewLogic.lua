
--组队副本 队伍
GroupStageTeamViewLogic = class("GroupStageTeamViewLogic",ViewBaseLogic)
-------------------------------------------------------
function GroupStageTeamViewLogic:ctor()
	self.CCS_FILE_NAME_PREFIX = Config.CSB_FILE_DIR_1
	self.csbName = "zuduifuben_zuduiduiwu2"
	self.fullScene = false
	self.viewLevel = SceneHelper.LAYER_TYPE.SECOND_LYAER
end

function GroupStageTeamViewLogic:onOpen()
	self:initUI()
end

function GroupStageTeamViewLogic:initUI()
	self.Panel_1 = self:getChildByName("Panel_1")
	self.btn_close = self.Panel_1:getChildByName("btn_close")
	self.txt_title = self.Panel_1:getChildByName("txt_title")
	self.txt_stageName = self.Panel_1:getChildByName("txt_stageName")
	self.btn_editTeam = self.Panel_1:getChildByName("btn_editTeam")
	self.Panel_player = self.Panel_1:getChildByName("Panel_player")
	self.player1 = self.Panel_player:getChildByName("player1")
	self.player2 = self.Panel_player:getChildByName("player2")
	self.player3 = self.Panel_player:getChildByName("player3")
	self.btn_genghuan1 = self.Panel_1:getChildByName("btn_genghuan1")
	self.btn_genghuan2 = self.Panel_1:getChildByName("btn_genghuan2")
	self.btn_yijianhanhua = self.Panel_1:getChildByName("btn_yijianhanhua")
	self.btnTxt_yijianhanhua = self.btn_yijianhanhua:getChildByName("txt")
	self.btn_yaoqing = self.Panel_1:getChildByName("btn_yaoqing")
	self.btnTxt_yaoqing = self.btn_yaoqing:getChildByName("txt")
	self.btn_tuichu = self.Panel_1:getChildByName("btn_tuichu")
	self.btntxt_tuichu = self.btn_tuichu:getChildByName("txt")
	self.btn_begin = self.Panel_1:getChildByName("btn_begin")
	self.btnTxt_begin = self.btn_begin:getChildByName("txt")
	self.btn_ready = self.Panel_1:getChildByName("btn_ready")
	self.btnTxt_ready = self.btn_ready:getChildByName("txt")
	self.btn_tiaozhanling_goumai = self.Panel_1:getChildByName("btn_tiaozhanling_goumai")
	self.txt_tiaozhanling_shuliang = self.Panel_1:getChildByName("txt_tiaozhanling_shuliang")

	self.playerInfos = {self.player1, self.player2, self.player3}

	Util.setTextString(self.txt_title, LanUtil.getLan("GroupStageTxt_19"))
	Util.setTextString(self.btnTxt_yijianhanhua, LanUtil.getLan("GroupStageTxt_20"))
	Util.setTextString(self.btnTxt_yaoqing, LanUtil.getLan("GroupStageTxt_21"))
	Util.setTextString(self.btntxt_tuichu, LanUtil.getLan("GroupStageTxt_22"))
	Util.setTextString(self.btnTxt_begin, LanUtil.getLan("GroupStageTxt_23"))


	self:addClickEventListener(self.btn_close, function ()
		self:closeView()
	end)

	-- 编辑队伍
	self:addClickEventListener(self.btn_editTeam, function () 
		require "com.hqfy.warship.modules.groupstage.GroupStageCreateTeamViewLogic"
		GroupStageCreateTeamViewLogic.new(2):openView()
	end)
	-- 更换顺序
	self:addClickEventListener(self.btn_genghuan1, function ()
		GroupStageData.requestStageTeamPos(1, 2)
	end)
	-- 更换顺序
	self:addClickEventListener(self.btn_genghuan2, function ()
		GroupStageData.requestStageTeamPos(2, 3)
	end)
	-- 一键喊话
	self:addClickEventListener(self.btn_yijianhanhua, function ()
		require "com.hqfy.warship.modules.groupstage.GroupStageSendMessageViewLogic"
		GroupStageSendMessageViewLogic.new():openView()
	end)
	-- 邀请入队
	self:addClickEventListener(self.btn_yaoqing, function ()
		local data = GroupStageData.teamself
		if data then 
			require "com.hqfy.warship.modules.groupstage.GroupStageInviteViewLogic"
			GroupStageInviteViewLogic.new(data.idstage):openView()
		end
	end)
	-- 退出队伍
	self:addClickEventListener(self.btn_tuichu, function ()
		local selfTeamData = GroupStageData.teamself
		local selfData = self:getSelfData()
		if selfData and selfData.ready == 1 and selfData.uid ~= selfTeamData.captain then  -- 队员在准备状态无法退出队伍
			Global.showTips(LanUtil.getLan("GroupStageTxt_51"))
		else
			GroupStageData.requestStageTeamQuit()
		end
	end)
	-- 进入副本
	self:addClickEventListener(self.btn_begin, function ()
		local data = GroupStageData.teamself
		for i,playerData in ipairs(data.members or {}) do
			if playerData.ready ~= 1 then -- 玩家未准备
				Global.showTips(LanUtil.getLan("GroupStageTxt_44"))
				return 
			end
		end
		-- self:closeView()
		GroupStageData.requestStageTeamStartTeam()
	end)
	-- 准备
	self:addClickEventListener(self.btn_ready, function ()
		if self._selfData then 
			if self._selfData.ready == 1 then 
				GroupStageData.requestStageTeamReady(0)
			else
				GroupStageData.requestStageTeamReady(1)
			end
		end
	end)
	-- 购买挑战令
	self:addClickEventListener(self.btn_tiaozhanling_goumai, function ()
		self:autoCancelReady()
		-- EventSystem.dispatchEvent(EventType.MenuOpt_OpenView,ModuleManager.SHOP)
		local showTxt = ""
		local baginfo = BagData.getDropInfo({type=GoodsConstant.PROP, id=PropertyKey.ITEM_Tiaozhanling, count=1})
		local itemCount = BagData.getPropCountByID(PropertyKey.ITEM_Tiaozhanling)
		local buyCount = GroupStageData.countbuy or 0
		if itemCount > 0 then 
			showTxt = LanUtil.getLan("GroupStageTxt_55", 1, baginfo.iconSmall)
		else
			baginfo = BagData.getDropInfo({type=GoodsConstant.DIAMOND, id=0, count=1})
			local SpecConfigTemplate = TemplateUtil.getData("SpecConfigTemplate")
			showTxt = LanUtil.getLan("GroupStageTxt_57", SpecConfigTemplate[427].num, baginfo.iconSmall, buyCount, SpecConfigTemplate[426].num)
		end

		
		Alert.show2(showTxt, {buttons={"BTN_CANCEL","BTN_CONFIRM"},yOffset=-20,callback=function(i)
			if i == 2 then
				GroupStageData.requestStageTeamBuyCount(1)
			end
		end})
	end)

	self:updateInfo(true)
end

function GroupStageTeamViewLogic:updateInfo(isInit)
	local data = GroupStageData.teamself
	if not data then 
		if isInit then 
			self:processPlayerInfo(self.player1, nil)
			self:processPlayerInfo(self.player2, nil)
			self:processPlayerInfo(self.player3, nil)
			self.btn_editTeam:setVisible(false)
			self.btn_yijianhanhua:setVisible(false)
			self.btn_yaoqing:setVisible(false)
			self.btn_begin:setVisible(false)
			self.btn_genghuan1:setVisible(false)
			self.btn_genghuan2:setVisible(false)
			self.btn_ready:setVisible(false)
		else
			self:closeView()
		end
		return
	end
	-- data.captain = PlayerData.userid
	self._data = data
	local GroupStageDataTemplate = TemplateUtil.getData("GroupStageDataTemplate")
	local stageCfg = GroupStageDataTemplate[data.idstage]
	if stageCfg then 
		Util.setTextString(self.txt_stageName, LanUtil.getLan(stageCfg.name))
	else
		Util.setTextString(self.txt_stageName, "")
	end
	if data.captain == PlayerData.userid then 
		self._isCaptain = true
		self.btn_editTeam:setVisible(true)
		self.btn_yijianhanhua:setVisible(true)
		self.btn_yaoqing:setVisible(true)
		self.btn_begin:setVisible(true)
		self.btn_genghuan1:setVisible(true)
		self.btn_genghuan2:setVisible(true)
		self.btn_ready:setVisible(false)
	else
		self._isCaptain = false
		self.btn_editTeam:setVisible(false)
		self.btn_yijianhanhua:setVisible(false)
		self.btn_yaoqing:setVisible(false)
		self.btn_begin:setVisible(false)
		self.btn_genghuan1:setVisible(false)
		self.btn_genghuan2:setVisible(false)
		self.btn_ready:setVisible(true)
	end

	self:processPlayerInfo(self.player1, nil)
	self:processPlayerInfo(self.player2, nil)
	self:processPlayerInfo(self.player3, nil)
	for i,v in ipairs(data.members or {}) do
		self:processPlayerInfo(self.playerInfos[v.pos], v)
	end

	self._selfData = self:getSelfData()
	if self._selfData then 
		if self._selfData.ready == 1 then 
			Util.setTextString(self.btnTxt_ready, LanUtil.getLan("GroupStageTxt_24"))
		else
			Util.setTextString(self.btnTxt_ready, LanUtil.getLan("GroupStageTxt_25"))
		end
	end

	local SpecConfigTemplate = TemplateUtil.getData("SpecConfigTemplate")
	self._maxFreeCount 	= SpecConfigTemplate[428].num
	local leftCount = GroupStageData.countfree or 0
	Util.setTextString(self.txt_tiaozhanling_shuliang, LanUtil.getLan("GroupStageTxt_54", leftCount, self._maxFreeCount))
	-- local itemCount = BagData.getPropCountByID(PropertyKey.ITEM_Tiaozhanling)
	-- Util.setTextString(self.txt_tiaozhanling_shuliang, itemCount)
end

-- 玩家信息
function GroupStageTeamViewLogic:processPlayerInfo(playerItem, playerData)
	if not playerItem.inited then 
		playerItem.inited = true
		playerItem.txt_duizhang = playerItem:getChildByName("txt_duizhang")
		playerItem.txt_duiyuan = playerItem:getChildByName("txt_duiyuan")
		playerItem.Panel_zhunbei = playerItem:getChildByName("Panel_zhunbei")
		playerItem.txt_zhunbei = playerItem.Panel_zhunbei:getChildByName("txt_zhunbei")
		playerItem.txt_name = playerItem:getChildByName("txt_name")
		playerItem.img_zhandoulidi = playerItem:getChildByName("img_zhandoulidi")
		playerItem.img_zhandouli = playerItem:getChildByName("img_zhandouli")
		playerItem.txt_zhandouli = playerItem:getChildByName("txt_zhandouli")
		playerItem.img_heisetouxiang = playerItem:getChildByName("img_heisetouxiang")
		playerItem.img_touxiang = playerItem:getChildByName("img_touxiang")
		playerItem.img_duizhangqizhi = playerItem:getChildByName("img_duizhangqizhi")
		playerItem.img_juntuanbiaozhi = playerItem:getChildByName("img_juntuanbiaozhi")
		playerItem.txt_dengji = playerItem:getChildByName("txt_dengji")
		playerItem.btn_qingli = playerItem:getChildByName("btn_qingli")
		playerItem.btnTxt_qingli = playerItem.btn_qingli:getChildByName("txt")

		Util.setTextString(playerItem.txt_duizhang, LanUtil.getLan("GroupStageTxt_26"))
		Util.setTextString(playerItem.txt_duiyuan, LanUtil.getLan("GroupStageTxt_27"))
		Util.setTextString(playerItem.txt_zhunbei, LanUtil.getLan("GroupStageTxt_28"))
		Util.setTextString(playerItem.btnTxt_qingli, LanUtil.getLan("GroupStageTxt_29"))

		playerItem.txt_dengji:enableOutline(cc.c4b(0x00,0x00,0x00, 255), 2)
		playerItem.txt_dengji:setAdditionalKerning(-3)
		playerItem.txt_duizhang:enableOutline(cc.c4b(0x2c,0x21,0x1e, 255), 2)
		playerItem.txt_duizhang:setAdditionalKerning(-4)
		playerItem.txt_duiyuan:enableOutline(cc.c4b(0x00,0x00,0x00, 255), 2)
		playerItem.txt_duiyuan:setAdditionalKerning(-4)

		self:addClickEventListener(playerItem.btn_qingli, function ()
			if playerItem.data then 
				GroupStageData.requestStageTeamKick(playerItem.data.uid)
			end
		end)

	end
	playerItem.data = playerData
	if playerData then 
		playerItem.img_heisetouxiang:setVisible(false)
		playerItem.img_touxiang:setVisible(true)
		playerItem.img_zhandouli:setVisible(true)
		playerItem.img_zhandoulidi:setVisible(true)
		Util.setTextString(playerItem.txt_name, playerData.name)
		Util.setTextString(playerItem.txt_zhandouli, playerData.power)
		Util.setTextString(playerItem.txt_dengji, LanUtil.getLan("txt_lvPoint", playerData.level))
		CCX.addImageTo(playerItem.img_touxiang, IconInfo.getHeadIcon(playerData.head))
		if playerData.uid == self._data.captain then -- 队长
			playerItem.img_duizhangqizhi:setVisible(true)
			playerItem.txt_duizhang:setVisible(true)
			playerItem.txt_duiyuan:setVisible(false)
		else -- 队员
			playerItem.img_duizhangqizhi:setVisible(false)
			playerItem.txt_duizhang:setVisible(false)
			playerItem.txt_duiyuan:setVisible(true)
		end

		if playerData.ready == 1 then 
			playerItem.Panel_zhunbei:setVisible(true)
		else
			playerItem.Panel_zhunbei:setVisible(false)
		end

		if self._isCaptain and playerData.uid ~= PlayerData.userid then 
			playerItem.btn_qingli:setVisible(true)
		else
			playerItem.btn_qingli:setVisible(false)
		end
		local sameGuildNum = self:getSameGuildMemberNum(playerData)
		if sameGuildNum > 0 then 
			playerItem.img_juntuanbiaozhi:setVisible(true)
		else
			playerItem.img_juntuanbiaozhi:setVisible(false)
		end
	else
		playerItem.img_heisetouxiang:setVisible(true)
		playerItem.img_touxiang:setVisible(false)
		playerItem.img_zhandouli:setVisible(false)
		playerItem.img_zhandoulidi:setVisible(false)
		Util.setTextString(playerItem.txt_name, "")
		Util.setTextString(playerItem.txt_zhandouli, "")
		Util.setTextString(playerItem.txt_dengji, "")
		playerItem.img_duizhangqizhi:setVisible(false)
		playerItem.txt_duizhang:setVisible(false)
		playerItem.txt_duiyuan:setVisible(false)
		playerItem.Panel_zhunbei:setVisible(false)
		playerItem.btn_qingli:setVisible(false)
		playerItem.img_juntuanbiaozhi:setVisible(false)
	end
end
-- 自己的玩家数据
function GroupStageTeamViewLogic:getSelfData()
	local data = GroupStageData.teamself
	if data then 
		for i,v in ipairs(data.members or {}) do
			if v.uid == PlayerData.userid then 
				return v
			end
		end
	end
	return nil
end

-- 获取同服同军团其他队员数量
function GroupStageTeamViewLogic:getSameGuildMemberNum(playerData)
	local count = 0
	if playerData.guild and playerData.guild ~= 0 then 
		for i,v in ipairs(self._data.members or {}) do
			if v.uid ~= playerData.uid and v.server == playerData.server and v.guild == playerData.guild then 
				count = count + 1
			end
		end
	end
	return count
end
-- 自动取消准备状态
function GroupStageTeamViewLogic:autoCancelReady()
	if self._autoCancelReadyOff then return end
	local selfTeamData = GroupStageData.teamself
	local selfData = self:getSelfData()
	if selfData and selfData.ready == 1 and selfData.uid ~= selfTeamData.captain then -- 准备状态，取消准备
		GroupStageData.requestStageTeamReady(0)
		Global.showTips(LanUtil.getLan("GroupStageTxt_52"))
	end
end

function GroupStageTeamViewLogic:onClose()
	self:autoCancelReady()
end

-- 
local function evt_StageTeamDataUpdate(self)
	self:updateInfo()
end

local function onItemUpdate(self)
	self:updateInfo()
end

local function onStageTeamCountUpdate(self)
	self:updateInfo()
end

function GroupStageTeamViewLogic:initEventListener()
	self:registerEventListener(EventType.BagListRefresh, onItemUpdate)
	self:registerEventListener(EventType.StageTeamDataUpdate, evt_StageTeamDataUpdate)
	self:registerEventListener(EventType.StageTeamCountUpdate, onStageTeamCountUpdate)
end
