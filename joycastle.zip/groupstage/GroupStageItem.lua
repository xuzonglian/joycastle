-- 组队副本
local GroupStageItem = class("GroupStageItem", function()
	return cc.Sprite:create()
end)

----------------------------------------------------------

function GroupStageItem:ctor()
	self.node = cc.CSLoader:createNode("res/core_res/csb_new1/zuduifuben_zuocefubenliebiao_node.csb")
	self:addChild(self.node)
	self:initUI()
end
function GroupStageItem:setOwner(v)
	self.owner 	= v
end

----------------------------------------------------------
function GroupStageItem:initUI()
	self.img_kuang = self.node:getChildByName("img_kuang")
	self.txt_fubenming = self.node:getChildByName("txt_fubenming")
	self.img_zhezhao = self.node:getChildByName("img_zhezhao")
	self.img_fubentu = self.node:getChildByName("img_fubentu")
	self.Text_2 = self.node:getChildByName("Text_2")
	self.btn_jiangliyulan = self.node:getChildByName("btn_jiangliyulan")

	self.img_kuang:setTouchEnabled(true)
	self.img_kuang:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended and self.owner.stageList:isClicked() then
			local unlockState = GroupStageData.checkStageUnlockState(self.index)
			if unlockState == 0 then 
				self.owner:selectStage(self)
			else
				Global.showTips(LanUtil.getLan("GroupStage_unlock"..unlockState))
			end
		end
	end)
	self.btn_jiangliyulan:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended and self.owner.stageList:isClicked() then
			require "com.hqfy.warship.modules.groupstage.GroupStageRewardViewLogic"
			GroupStageRewardViewLogic.new(self.index):openView()
		end
	end)

	self.txt_fubenming:enableOutline(cc.c4b(0x2c,0x21,0x1e, 255), 2)
	self.txt_fubenming:setAdditionalKerning(-4)
end

----------------------------------------------------------
function GroupStageItem:UpdateInfo(data)
	self._data = data
	self.index = data.id
	Util.setTextString(self.txt_fubenming, LanUtil.getLan(data.name))
	PlistManager.loadByPath("img/zhengba/zudui.plist")
	CCX.addImageTo(self.img_fubentu, data.icon)
	if data.levelMin > PlayerData.level then 
		Util.setTextString(self.Text_2, LanUtil.getLan("GroupStageTxt_42", data.levelMin))
	else
		Util.setTextString(self.Text_2, "")
	end
	self:setSelected(false)
end

function GroupStageItem:setSelected(selectState)
	self.img_zhezhao:setVisible(not selectState)
end

----------------------------------------------------------
function GroupStageItem:destroy()
end
return GroupStageItem