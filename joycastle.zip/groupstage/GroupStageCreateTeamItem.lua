-- 组队副本 创建队伍Item
local GroupStageCreateTeamItem = class("GroupStageCreateTeamItem", function()
	return cc.Sprite:create()
end)

----------------------------------------------------------

function GroupStageCreateTeamItem:ctor()
	self.node = cc.CSLoader:createNode("res/core_res/csb_new1/zuduifuben_fubenxuanze.csb")
	self:addChild(self.node)
	self:initUI()
end
function GroupStageCreateTeamItem:setOwner(v)
	self.owner 	= v
end

----------------------------------------------------------
function GroupStageCreateTeamItem:initUI()
	self.CheckBox_1 = self.node:getChildByName("CheckBox_1")
	self.txt_fuben1 = self.node:getChildByName("txt_fuben1")
end

----------------------------------------------------------
function GroupStageCreateTeamItem:UpdateInfo(data)
	self._data = data
	self.index = data.id
	Util.setTextString(self.txt_fuben1, LanUtil.getLan(data.name))
	self:setSelected(false)
end

function GroupStageCreateTeamItem:setSelected(selectState)
	self.CheckBox_1:setSelected(selectState)
end

----------------------------------------------------------
function GroupStageCreateTeamItem:destroy()
end
return GroupStageCreateTeamItem