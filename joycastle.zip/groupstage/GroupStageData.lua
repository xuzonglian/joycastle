--[[
    @-- 组队副本
    @-- xuzonglian
    @-- 2016-07-08
--]]
module("GroupStageData", package.seeall)
function clear()
	dataInited = false
	stagelist = {}
	teamself = nil -- 自己的队伍数据

	countfree = 0 	-- 当前剩余次数
	countbuy = 0 	-- 已经购买次数
end
clear()

-- 返回值：0:：已解锁可以打。1：前置关卡未单人通关。2：等级未满足
function checkStageUnlockState(idstage)
	local GroupStageDataTemplate = TemplateUtil.getData("GroupStageDataTemplate")
	local stageCfg = GroupStageDataTemplate[idstage]
	if stageCfg then 
		-- 策划要取消[前置关卡未单人通关]的限制
		-- local reqStage = stageCfg.reqStage
		-- if reqStage and reqStage > 0 then 
		-- 	local previewPassed = false
		-- 	for i,v in ipairs(stagelist) do
		-- 		if v == reqStage then 
		-- 			previewPassed = true
		-- 			break 
		-- 		end
		-- 	end
		-- 	if not previewPassed then 
		-- 		return 1
		-- 	end
		-- end

		if stageCfg.levelMin > PlayerData.level then 
			return 2
		end
	end
	return 0
end
-- 可以打的最高难度关卡
function getMaxAvailableStageID()
	local GroupStageDataTemplate = TemplateUtil.getData("GroupStageDataTemplate")
	local maxID = 0
	for k,v in ipairs(ReadOnly.forPair(GroupStageDataTemplate)) do
		if v.id > maxID and checkStageUnlockState(v.id)==0 then 
			maxID = v.id
		end
	end
	return maxID
end

-- 打开队伍界面 
function openTeamView()
	require "com.hqfy.warship.modules.groupstage.GroupStageTeamViewLogic"
	OpenViewManager.openView({ViewLogic=GroupStageTeamViewLogic,bakCallback=function(viewLogic,userData)
		viewLogic._autoCancelReadyOff = true
	end,restoreCallback=function(viewLogic,userData)
	end})
end
---------------------------------------------------------------------------------
-- 关卡的队伍列表
function requestStageTeamList(idstage)
	NetMessageSystem.sendRequest(ID_DceStageTeamList, {idstage=idstage})
end

-- 请求玩家自己的数据
function requestStageTeamData(idstage)
	NetMessageSystem.sendRequest(ID_DceStageTeamData)
end

-- 编辑队伍
function requestStageTeamChange(idstage, available)
	NetMessageSystem.sendRequest(ID_DceStageTeamChange, {idstage=idstage, available=available})
end
-- 单人开战
function requestStageTeamStartSingle(idstage)
	-- NetMessageSystem.sendRequest(ID_DceStageTeamStart)
	EventSystem.dispatchEvent(EventType.Battle_GroupStageSingle, {type=BattleResultManager.BATTLE_TYPE.BATTLE_TYPE_GroupStage, targetID=idstage})
end
-- 开战
function requestStageTeamStartTeam()
	NetMessageSystem.sendRequest(ID_DceStageTeamStart)
end
-- 创建队伍
function requestStageTeamCreate(idstage, available)
	NetMessageSystem.sendRequest(ID_DceStageTeamCreate, {idstage=idstage, available=available})
end
-- 退出队伍
function requestStageTeamQuit()
	NetMessageSystem.sendRequest(ID_DceStageTeamQuit)
end
-- 调整队伍成员位置
function requestStageTeamPos(pos1, pos2)
	NetMessageSystem.sendRequest(ID_DceStageTeamPos, {pos1=pos1, pos2=pos2})
end
-- 踢人
function requestStageTeamKick(uidkick)
	NetMessageSystem.sendRequest(ID_DceStageTeamKick, {uidkick=uidkick})
end
-- 加入队伍
function requestStageTeamJoin(indexteam)
	NetMessageSystem.sendRequest(ID_DceStageTeamJoin, {indexteam=indexteam})
end
-- 准备
function requestStageTeamReady(ready)
	NetMessageSystem.sendRequest(ID_DceStageTeamReady, {ready=ready})
end
-- 显示成员可邀请列表
function requestStageTeamGuildMemberList(idstage)
	NetMessageSystem.sendRequest(ID_DceStageTeamGuildMemberList, {idstage=idstage})
end
-- 购买挑战次数
function requestStageTeamBuyCount(pCount)
	NetMessageSystem.sendRequest(ID_DceStageTeamBuyCount,{count = pCount})
end

-- message TeamStageData
-- {
-- 	optional int32		idstage			= 1;
-- 	optional int32		passself		= 2;//个人通关

-- }
-- message StageTeam
-- {
-- 	optional int32 		indexteam	= 1;//
-- 	optional int32		idstage		= 2;//目标副本
-- 	optional int32		available	= 3;//可见
-- 	optional string		captain		= 4;//队长
-- 	repeated StageTeamMember	members	= 5;//队伍成员		
-- }
-- message StageAward
-- {
-- 	optional int32 		campaignID = 1;//战役ID
-- 	optional int32 		star = 2;//总星级
-- 	optional int32  	reward     = 3;//奖励
-- }
-- message StageBuffData
-- {
-- 	optional int32		id 					= 1;
-- 	optional int32		entrance 		= 2;
-- 	optional int32		state 			= 3;
-- 	optional int32		eventtype 	= 4;
-- 	optional int32		stageid 		= 5;
-- }
-- message StageData
-- {
-- 	optional int32 			 stageID     			= 1;	//关卡id
-- 	optional int32 			 todayCount  			= 2;	//今日胜利次数
-- 	optional int32 			 star        			= 3;	//最高通关星级
-- 	optional int32 			 todaybuyCnt 			= 4;	//今日购买次数
-- }
-- message StageTeamMember
-- {
-- 	optional string		uid		= 1;
-- 	optional int32		pos		= 2;		
-- 	optional int32 		level 	= 3;
-- 	optional int32 		camp 	= 4;
-- 	optional int32 		head 	= 5;
-- 	optional int32 		power 	= 6;
-- 	optional int32 		vip 	= 7;
-- 	optional int32		ready	= 8;//准备状态
-- 	optional string 	name	= 9;
-- 	optional string		guildname	= 10;
-- }


-- 请求玩家自己的数据
local function Dse_StageTeamData( pkg )
	-- repeated int32			stagelist	= 1;//
	-- optional StageTeam		teamself	= 2;//
	dataInited = true
	local oldData = teamself
	stagelist = pkg.stagelist or {}
	teamself = pkg.teamself
	countfree = pkg.countfree or 0
	countbuy = pkg.countbuy or 0
	if (oldData and not teamself) or (teamself and not oldData) then --退出/被踢出 or 加入或者创建队伍 
		EventSystem.dispatchEvent(EventType.StageTeamListRefresh)
	end
	EventSystem.dispatchEvent(EventType.StageTeamDataUpdate)
end

-- 编辑队伍
local function Dse_StageTeamChange( pkg )
	-- optional int32		res			= 1;//
	-- optional int32		idstage		= 2;//目标副本
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
	end
end

-- 创建队伍
local function Dse_StageTeamCreate( pkg )
	-- optional int32		res			= 1;//
	-- optional int32		idstage		= 2;//
	-- optional int32		available	= 3;//可见
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
		-- require "com.hqfy.warship.modules.groupstage.GroupStageTeamViewLogic"
		-- GroupStageTeamViewLogic.new():openView()
		GroupStageData.openTeamView()
	end
end

-- 加入队伍
local function Dse_StageTeamJoin( pkg )
	-- optional int32			res			= 1;//
	-- optional int32			indexteam	= 2;//
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	elseif GroupStageData.isViewOpen then --已打开组队界面时加入队伍则打开队伍界面
		-- require "com.hqfy.warship.modules.groupstage.GroupStageTeamViewLogic"
		-- GroupStageTeamViewLogic.new():openView()
		GroupStageData.openTeamView()
	else -- 未打开组队界面时加入队伍则打开组队副本界面
		if ChatManage then 
			ChatManage.close()
		end
		EventSystem.dispatchEvent(EventType.MenuOpt_OpenView, {name=ModuleManager.GroupStage})
	end
end

-- 踢人
local function Dse_StageTeamKick( pkg )
	-- optional int32		res			= 1;//
	-- optional int64		uidkick		= 2;//
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
	end
end

-- 关卡的队伍列表
local function Dse_StageTeamList( pkg )
	-- optional int32		res		= 1;//
	-- optional int32		idstage		= 2;//
	-- repeated StageTeam	teamlist	= 3;//
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
		EventSystem.dispatchEvent(EventType.StageTeamListUpdate, pkg)
	end
end

-- 调整队伍成员位置
local function Dse_StageTeamPos( pkg )
	-- optional int32		res			= 1;//
	-- optional int32		pos1		= 2;//
	-- optional int32		pos2		= 3;
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
	end
end

-- 退出队伍
local function Dse_StageTeamQuit( pkg )
	-- optional int32		res			= 1;//
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
	end
end

-- 准备
local function Dse_StageTeamReady( pkg )
	-- optional int32		res			= 1;//
	-- optional int32		ready		= 2;//1准备
	-- optional BattlePlayer	battleplayer	= 3;//后端，前端不用
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
	end
end

-- 军团成员可邀请列表
local function Dse_StageTeamGuildMemberList( pkg )
	-- optional int32   res    	= 1;//0 success
	-- optional int32   idstage    = 2;//
	-- repeated StageTeamGuildMember  memberlist    = 3;//
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
		EventSystem.dispatchEvent(EventType.StageTeamGuildMemberList, pkg)
	end
end

-- 开战
local function Dse_StageTeamStart( pkg )
	-- optional int32			res			= 1;//前端可用
	-- optional int32			indexteam	= 2;//前端可用
	if GroupStageData.isViewOpen then -- 打开组队副本界面的时候才进入战斗
		if pkg.res and pkg.res > 0 then
			Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
		else
			EventSystem.dispatchEvent(EventType.Battle_GroupStageTeam, {type=BattleResultManager.BATTLE_TYPE.BATTLE_TYPE_GroupStage, indexteam=pkg.indexteam})
		end
	end
end

-- 购买次数
local function Dse_StageTeamBuyCount( pkg )
	-- optional int32	res			= 1;//
	-- optional int32	countfree	= 2;//次数奖励
	-- optional int32	countbuy	= 3;//购买次数
	if pkg.res and pkg.res > 0 then
		Global.showTips(LanUtil.getLan("socketError_"..pkg.res))
	else
		Global.showTips(LanUtil.getLan("GroupStageTxt_56"))
		countfree = pkg.countfree or 0
		countbuy = pkg.countbuy or 0
		EventSystem.dispatchEvent(EventType.StageTeamCountUpdate)
	end
end

-- 次数同步
local function Dse_StageTeamCount( pkg )
	-- optional int32	countfree	= 1;//次数奖励
	-- optional int32	countbuy	= 2;//购买次数
	countfree = pkg.countfree or 0
	countbuy = pkg.countbuy or 0
	EventSystem.dispatchEvent(EventType.StageTeamCountUpdate)
end

function init()
	NetMessageSystem.registerMessageListener(ID_DseStageTeamData, Dse_StageTeamData)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamChange, Dse_StageTeamChange)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamCreate, Dse_StageTeamCreate)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamJoin, Dse_StageTeamJoin)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamKick, Dse_StageTeamKick)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamList, Dse_StageTeamList)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamPos, Dse_StageTeamPos)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamQuit, Dse_StageTeamQuit)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamReady, Dse_StageTeamReady)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamGuildMemberList, Dse_StageTeamGuildMemberList)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamStart, Dse_StageTeamStart)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamBuyCount, Dse_StageTeamBuyCount)
	NetMessageSystem.registerMessageListener(ID_DseStageTeamCount, Dse_StageTeamCount)
end

function uninit()
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamData, Dse_StageTeamData)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamChange, Dse_StageTeamChange)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamCreate, Dse_StageTeamCreate)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamJoin, Dse_StageTeamJoin)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamKick, Dse_StageTeamKick)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamList, Dse_StageTeamList)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamPos, Dse_StageTeamPos)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamQuit, Dse_StageTeamQuit)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamReady, Dse_StageTeamReady)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamStart, Dse_StageTeamStart)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamBuyCount, Dse_StageTeamBuyCount)
	NetMessageSystem.unregisterMessageListener(ID_DseStageTeamCount, Dse_StageTeamCount)
end

