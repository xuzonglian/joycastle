-- 组队副本 邀请入队item
local GroupStageInviteItem = class("GroupStageInviteItem", function()
	return cc.Sprite:create()
end)

----------------------------------------------------------

function GroupStageInviteItem:ctor()
	self.node = cc.CSLoader:createNode("res/core_res/csb_new1/zuduifuben_wanjialiebiao_node.csb")
	self:addChild(self.node)
	self:initUI()
end
function GroupStageInviteItem:setOwner(v)
	self.owner 	= v
end

----------------------------------------------------------
function GroupStageInviteItem:initUI()
	self.txt_mingzi = self.node:getChildByName("txt_mingzi")
	self.txt_zhanli = self.node:getChildByName("txt_zhanli")
	self.btn_yaoqing = self.node:getChildByName("btn_yaoqing")
	self.btnTxt_yaoqing = self.btn_yaoqing:getChildByName("txt")
	self.img_touxiang = self.node:getChildByName("img_touxiang")
	self.txt_dengji = self.node:getChildByName("txt_dengji")

	self.btn_yaoqing:addTouchEventListener(function (sender,eventType)
		if eventType == ccui.TouchEventType.ended and self.owner.memberList:isClicked() then
			local teamself = GroupStageData.teamself
			if self._data and teamself then 
				self.owner.invitedList[self._data.uid] = true
				Util.setTextString(self.btnTxt_yaoqing, LanUtil.getLan("GroupStageTxt_31"))
				self.btn_yaoqing:setButtonEnabled(false)
				NetMessageSystem.sendRequest(ID_DceChat, {type=ChatData.LABEL.GroupStage_invite, uid=self._data.uid, content="", indexteam=teamself.indexteam, idgroupstage=teamself.idstage}, true )
			end
		end
	end)
end

----------------------------------------------------------
function GroupStageInviteItem:UpdateInfo(data)
	self._data = data
	Util.setTextString(self.txt_mingzi, data.name)
	Util.setTextString(self.txt_zhanli, LanUtil.getLan("TXT_PLAYER_POWER", data.power))
	Util.setTextString(self.txt_dengji, LanUtil.getLan("txt_lvPoint", data.level))
	CCX.addImageTo(self.img_touxiang, IconInfo.getHeadIcon(data.head))
	if self.owner.invitedList[data.uid] then 
		Util.setTextString(self.btnTxt_yaoqing, LanUtil.getLan("GroupStageTxt_31"))
		self.btn_yaoqing:setButtonEnabled(false)
	else
		Util.setTextString(self.btnTxt_yaoqing, LanUtil.getLan("GroupStageTxt_21"))
		self.btn_yaoqing:setButtonEnabled(true)
	end
end

----------------------------------------------------------
function GroupStageInviteItem:destroy()
end
return GroupStageInviteItem