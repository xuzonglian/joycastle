-- 组队副本
local GroupStageTeamItem = class("GroupStageTeamItem", function()
	return cc.Sprite:create()
end)

----------------------------------------------------------

function GroupStageTeamItem:ctor()
	self.node = cc.CSLoader:createNode("res/core_res/csb_new1/zuduifuben_youcefubenliebiao_node.csb")
	self:addChild(self.node)
	self:initUI()
end
function GroupStageTeamItem:setOwner(v)
	self.owner 	= v
end

----------------------------------------------------------
function GroupStageTeamItem:initUI()
	self.Panel_1 = self.node:getChildByName("Panel_1")
	self.Panel_2 = self.node:getChildByName("Panel_2")
	self.txt_fubenming = self.node:getChildByName("txt_fubenming")
	self.txt_juntuanming = self.node:getChildByName("txt_juntuanming")
	self.playerHead_1 = self.node:getChildByName("playerHead_1")
	self.playerHead_2 = self.node:getChildByName("playerHead_2")
	self.playerHead_3 = self.node:getChildByName("playerHead_3")
	self.btn_chakan = self.Panel_1:getChildByName("btn_chakan")
	self.btnTxt_chakan = self.btn_chakan:getChildByName("txt")
	self.btn_jiaru = self.Panel_2:getChildByName("btn_jiaru")
	self.btnTxt_jiaru = self.btn_jiaru:getChildByName("txt")

	self.playerHeads = {self.playerHead_1, self.playerHead_2, self.playerHead_3}

	Util.setTextString(self.btnTxt_chakan, LanUtil.getLan("GroupStageTxt_8"))
	Util.setTextString(self.btnTxt_jiaru, LanUtil.getLan("GroupStageTxt_9"))
	self.btn_chakan:addTouchEventListener(function (sender,eventType)
		if eventType == ccui.TouchEventType.ended and self.owner.groupList:isClicked() then
			-- require "com.hqfy.warship.modules.groupstage.GroupStageTeamViewLogic"
			-- GroupStageTeamViewLogic.new():openView()
			GroupStageData.openTeamView()
		end
	end)
	self.btn_jiaru:addTouchEventListener(function (sender,eventType)
		if eventType == ccui.TouchEventType.ended and self.owner.groupList:isClicked() then
			GroupStageData.requestStageTeamJoin(self._data.indexteam)
		end
	end)

	self.evt_StageTeamDataUpdate = function ()
		-- 修复线上BUG
		if tolua.isnull(self.Panel_1) or not self._data then
			return 
		end
		local teamself = GroupStageData.teamself
		if (teamself and teamself.indexteam == self._data.indexteam) or self._isSelfTeam then 
			self:UpdateInfo(self._data)
		end
	end
	EventSystem.registerEventListener(EventType.StageTeamDataUpdate, self.evt_StageTeamDataUpdate)
end

----------------------------------------------------------
function GroupStageTeamItem:UpdateInfo(data)
	local teamself = GroupStageData.teamself
	if teamself and teamself.indexteam == data.indexteam then 
		data = GroupStageData.teamself
	end
	self._data = data
	-- local GroupStageDataTemplate = TemplateUtil.getData("GroupStageDataTemplate")
	-- local stageCfg = GroupStageDataTemplate[data.idstage]
	-- if stageCfg then
	-- 	Util.setTextString(self.txt_fubenming, LanUtil.getLan(stageCfg.name))
	-- end
	self._isSelfTeam = self:checkIsSelfTeam(data)

	local captainData = self:getCaptainData()
	Util.setTextString(self.txt_fubenming, LanUtil.getLan("GroupStageTxt_45", captainData.name))
	if captainData.guild and captainData.guild > 0 then 
		Util.setTextString(self.txt_juntuanming, LanUtil.getLan("TXT_PLAYER_GUILD", captainData.guildname or ""))
	else
		Util.setTextString(self.txt_juntuanming, LanUtil.getLan("TXT_PLAYER_GUILD", LanUtil.getLan("TXT_COMMON_NONE")))
	end

	self:processPlayerInfo(self.playerHead_1, nil)
	self:processPlayerInfo(self.playerHead_2, nil)
	self:processPlayerInfo(self.playerHead_3, nil)
	for i,v in ipairs(data.members or {}) do
		self:processPlayerInfo(self.playerHeads[v.pos], v)
	end

	if self._isSelfTeam then 
		self.Panel_1:setVisible(true)
		self.Panel_2:setVisible(false)
	else
		self.Panel_1:setVisible(false)
		self.Panel_2:setVisible(true)
	end
end

function GroupStageTeamItem:processPlayerInfo(item, playerData)
	if not item then return end
	if not item.inited then 
		item.img_benduitouxiangkuang = item:getChildByName("img_benduitouxiangkuang")
		item.img_bieduitouxiangkuang = item:getChildByName("img_bieduitouxiangkuang")
		item.img_heisetouxiang = item:getChildByName("img_heisetouxiang")
		item.img_touxiang = item:getChildByName("img_touxiang")
		item.txt_dengji = item:getChildByName("txt_dengji")
		item.img_qi = item:getChildByName("img_qi")
		item.inited = true
		item.txt_dengji:enableOutline(cc.c4b(0x00,0x00,0x00, 255), 2)
		item.txt_dengji:setAdditionalKerning(-4)
	end
	if playerData then 
		item.img_touxiang:setVisible(true)
		item.img_heisetouxiang:setVisible(false)
		if self._isSelfTeam then 
			item.img_benduitouxiangkuang:setVisible(true)
			item.img_bieduitouxiangkuang:setVisible(false)
		else
			item.img_benduitouxiangkuang:setVisible(false)
			item.img_bieduitouxiangkuang:setVisible(true)
		end
		Util.setTextString(item.txt_dengji, LanUtil.getLan("txt_lvPoint", playerData.level))
		if playerData.uid == self._data.captain then 
			item.img_qi:setVisible(true)
		else
			item.img_qi:setVisible(false)
		end
		CCX.addImageTo(item.img_touxiang, IconInfo.getHeadIcon(playerData.head))
	else
		item.img_heisetouxiang:setVisible(true)
		item.img_benduitouxiangkuang:setVisible(false)
		item.img_bieduitouxiangkuang:setVisible(true)
		item.img_touxiang:setVisible(false)
		item.img_qi:setVisible(false)
		Util.setTextString(item.txt_dengji, "")
	end
end

-- 是否是自己所在的队伍
function GroupStageTeamItem:checkIsSelfTeam()
	for i,v in pairs(self._data.members or {}) do
		if v.uid == PlayerData.userid then 
			return true
		else
		end
	end
	return false
end

-- 获取队长数据
function GroupStageTeamItem:getCaptainData()
	for i,v in pairs(self._data.members or {}) do
		if v.uid == self._data.captain then 
			return v
		end
	end
	return nil
end
----------------------------------------------------------
function GroupStageTeamItem:destroy()
	EventSystem.unregisterEventListener(EventType.StageTeamDataUpdate, self.evt_StageTeamDataUpdate)
end
return GroupStageTeamItem