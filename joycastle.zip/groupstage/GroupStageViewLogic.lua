
--组队副本
GroupStageViewLogic = class("GroupStageViewLogic",ViewBaseLogic)
-------------------------------------------------------

local _instance = nil
function GroupStageViewLogic:getInstance()
	return _instance
end

function GroupStageViewLogic:ctor()
	self.CCS_FILE_NAME_PREFIX = Config.CSB_FILE_DIR_1
	self.csbName = "zuduifuben_fubenjiemian"
	self.fullScene = true
	self.viewLevel = SceneHelper.LAYER_TYPE.BASE_II_LYAER

	local SpecConfigTemplate = TemplateUtil.getData("SpecConfigTemplate")
	self._maxBuyCount 	= SpecConfigTemplate[426].num
	self._buyCost 		= SpecConfigTemplate[427].num
	self._maxFreeCount 	= SpecConfigTemplate[428].num
end

function GroupStageViewLogic:onOpen()

	_instance = self
	GroupStageData.isViewOpen = true
	GroupStageData.requestStageTeamData()
	self:initUI()


	local ice = MathUtil.getBitFromInt32(PlayerData.guide_flags, 11)
	-- print(" ------------------------ 进入史诗战役界面软引导 ice = ",ice)
	if not ice then
		if not DirectData.isDirecting then
			EventSystem.dispatchEvent(EventType.Event_enter_GroupStageView)
		end
	end
end

local function tapClose(self)
	self:closeView()
end
local function tapExplain(self)
	ExplainViewLogic.new(63):openView()
end

function GroupStageViewLogic:initUI()
	local baseView = self:getView()
	self.img_shangjiantou = baseView:getChildByName("img_shangjiantou")
	self.img_xiajiantou = baseView:getChildByName("img_xiajiantou")
	self.txt_title = baseView:getChildByName("txt_title")
	self.btn_create = baseView:getChildByName("btn_create")
	self.btnTxt_create = self.btn_create:getChildByName("txt")
	self.btn_refresh = baseView:getChildByName("btn_refresh")
	self.btnTxt_refresh = self.btn_refresh:getChildByName("txt")
	self.btn_enter = baseView:getChildByName("btn_enter")
	self.btnTxt_enter = self.btn_enter:getChildByName("txt")
	self.btn_jiahao = baseView:getChildByName("btn_jiahao")
	self.txt_huobishuliang = baseView:getChildByName("txt_huobishuliang")
	self.txt_fubentitle = baseView:getChildByName("txt_fubentitle")
	self.img_tiaozhanling = baseView:getChildByName("img_tiaozhanling")
	self.Panel_fubenliebiao = baseView:getChildByName("Panel_fubenliebiao")
	self.Panel_duiwuliebiao = baseView:getChildByName("Panel_duiwuliebiao")
	self.btn_shuoming = baseView:getChildByName("btn_shuoming")
	self.btnTxt_shuoming = self.btn_shuoming:getChildByName("txt")
	self.btn_close = baseView:getChildByName("btn_close")

	self.img_shangjiantou:setVisible(false)
	self.img_xiajiantou:setVisible(false)

	Util.setTextString(self.txt_title, LanUtil.getLan("GroupStageTxt_3"))
	Util.setTextString(self.btnTxt_create, LanUtil.getLan("GroupStageTxt_4"))
	Util.setTextString(self.btnTxt_refresh, LanUtil.getLan("GroupStageTxt_5"))
	Util.setTextString(self.btnTxt_enter, LanUtil.getLan("GroupStageTxt_6"))
	Util.setTextString(self.btnTxt_shuoming, LanUtil.getLan("LeagueTxt_explain"))

	self:addClickEventListener(self.btn_shuoming, tapExplain)
	self:addClickEventListener(self.btn_close, tapClose)

	self:addClickEventListener(self.btn_create, function ()
		if GroupStageData.teamself then 
			Global.showTips(LanUtil.getLan("GroupStageTxt_7"))
		else
			require "com.hqfy.warship.modules.groupstage.GroupStageCreateTeamViewLogic"
			GroupStageCreateTeamViewLogic.new(1, self.curStageID):openView()
		end
	end)
	self:addClickEventListener(self.btn_refresh, function ()
		local curTime = HeartBeatManager.getTime()
		local lastRefreshTime = GroupStageData.lastRefreshTime or 0
		if curTime - lastRefreshTime > 5 then 
			GroupStageData.lastRefreshTime = curTime
			GroupStageData.requestStageTeamList(self.curStageID)
		else
			Global.showTips(LanUtil.getLan("GroupStageTxt_49"))
		end
	end)
	self:addClickEventListener(self.btn_enter, function ()
		local confirmCallback = function ()
			-- local itemCount = BagData.getPropCountByID(PropertyKey.ITEM_Tiaozhanling)
			local leftCount = GroupStageData.countfree or 0
			if leftCount < 1 then 
				Global.showTips(LanUtil.getLan("GroupStageTxt_41"))
				return
			end
			if self.curStageID then 
				GroupStageData.requestStageTeamStartSingle(self.curStageID)
			end
		end
		if self.curStageID and not GroupStageData._confirmOff and false then -- 不显示确认界面了 
			require "com.hqfy.warship.modules.groupstage.GroupStageSingleConfirmViewLogic"
			GroupStageSingleConfirmViewLogic.new(confirmCallback):openView()
		else
			confirmCallback()
		end
	end)
	self:addClickEventListener(self.btn_jiahao, function ()
		-- EventSystem.dispatchEvent(EventType.MenuOpt_OpenView,ModuleManager.SHOP)
		--com\hqfy\warship\modules\groupstage\GroupStageBuyPanle
		-- local showTxt = ""
		local baginfo = BagData.getDropInfo({type=GoodsConstant.PROP, id=PropertyKey.ITEM_Tiaozhanling, count=1})
		local itemCount = BagData.getPropCountByID(PropertyKey.ITEM_Tiaozhanling)
		local buyCount = GroupStageData.countbuy
		if itemCount > 0 then 
			showTxt = LanUtil.getLan("GroupStageTxt_55", 1, baginfo.iconSmall)
			Alert.show2(showTxt, {buttons={"BTN_CANCEL","BTN_CONFIRM"},yOffset=-20,callback=function(i)
				if i == 2 then
					GroupStageData.requestStageTeamBuyCount(1)
				end
			end})
		else
			local GroupStageBuyPanle = require("com.hqfy.warship.modules.groupstage.GroupStageBuyPanle")
			GroupStageBuyPanle.new():openView()
		end
	end)

	if GroupStageData.dataInited then 
		self:showStageList()
	end

end

-- 显示关卡列表
function GroupStageViewLogic:showStageList()
	local datalist = {}
	local GroupStageDataTemplate = TemplateUtil.getData("GroupStageDataTemplate")
	for k,v in pairs(ReadOnly.forPair(GroupStageDataTemplate)) do
		table.insert(datalist, v)
	end
	table.sort(datalist, function (a, b)
		return a.id < b.id
	end)
	if not self.curStageID then 
		local teamself = GroupStageData.teamself
		if teamself then -- 默认选中当前队伍所在关卡
			self.curStageID = teamself.idstage
		elseif GroupStageData.lastSelectStageID then -- 选中上次选中关卡
			self.curStageID = GroupStageData.lastSelectStageID
		elseif GroupStageData.dataInited then -- 选中可以打的最大难度关卡
			self.curStageID = GroupStageData.getMaxAvailableStageID()
		end
		if self.curStageID then 
			self.curStageCfg = GroupStageDataTemplate[self.curStageID]
		end
		self:updateInfo()
	else
		self.curStageCfg = GroupStageDataTemplate[self.curStageID]
		self:updateInfo()
	end
	if not self.stageList then
		local itemClass = require("com.hqfy.warship.modules.groupstage.GroupStageItem")
		local itemSize 		= cc.size(347,167)
		self.stageList = TileListHelper.new({listLayer=self.Panel_fubenliebiao,itemSize=itemSize,
			gap=cc.size(0,9),cacheKey="GroupStageItem",itemCreateCallback=function( ... )
				return itemClass.new()
			end,initCallback=function(item,data)	
				item:setOwner(self)			
				item:UpdateInfo(data)
				if self.curStageID == data.id then 
					self:selectStage(item)
				end
			end})
		self.stageList:setTouchEnabled(true)
	end
	self.stageList:setDataProvider(datalist, false)
	self.stageList:refresh()

	local index = 0
	for i,v in ipairs(datalist) do
		if v.id == self.curStageID then 
			index = i
			break
		end
	end
	if index > 0 then 
		self.stageList:at(index)
	end
end

-- 选择关卡
function GroupStageViewLogic:selectStage(item)
	if self.curStageItem == item and self.curStageID == item.index and item._selected == true then  -- 不重复select
		return 
	end
	if self.curStageItem == nil or self.curStageID ~= item.index then -- 第一次显示关卡 或者 切换关卡，需要申请新数据
		GroupStageData.requestStageTeamList(item.index)
	end
	if self.curStageItem and not tolua.isnull(self.curStageItem) then 
		self.curStageItem:setSelected(false)
	end
	self.curStageID = item.index
	GroupStageData.lastSelectStageID = item.index
	self.curStageCfg = item._data
	self.curStageItem = item
	self.curStageItem:setSelected(true)
	self:updateInfo()
end

function GroupStageViewLogic:updateInfo()
	-- local itemCount = BagData.getPropCountByID(PropertyKey.ITEM_Tiaozhanling)
	local leftCount = GroupStageData.countfree or 0
	Util.setTextString(self.txt_huobishuliang, LanUtil.getLan("GroupStageTxt_54", leftCount, self._maxFreeCount))
	if self.curStageCfg then 
		Util.setTextString(self.txt_fubentitle, LanUtil.getLan(self.curStageCfg.name))
	end
end

function GroupStageViewLogic:showGroupList(datalist)
	self.datalist = datalist or {}
	local teamself = GroupStageData.teamself
	if teamself and self.curStageID == teamself.idstage then 
		local tmpTeamData = nil
		for i,v in ipairs(self.datalist) do
			if v.indexteam == teamself.indexteam then -- 自己的队伍，提出来放最前面
				tmpTeamData = v
				table.remove(self.datalist, i)
				break
			end
		end
		table.insert(self.datalist, 1, teamself) -- 把自己队伍放最前面。当加入军团可见的队伍后，退出军团，也能看到队伍
	end
	-- log(#datalist)
	-- table.sort(datalist, function (a, b)
		-- return a.id < b.id
	-- end)
	if not self.groupList then
		local itemClass = require("com.hqfy.warship.modules.groupstage.GroupStageTeamItem")
		local itemSize 		= cc.size(882,150)
		self.groupList = TileListHelper.new({listLayer=self.Panel_duiwuliebiao,itemSize=itemSize,
			gap=cc.size(0,9),cacheKey="GroupStageTeamItem",itemCreateCallback=function( ... )
				return itemClass.new()
			end,initCallback=function(item,data)	
				item:setOwner(self)			
				item:UpdateInfo(data)
			end})
		self.groupList:setTouchEnabled(true)
	end
	self.groupList:setDataProvider(self.datalist, false)
	self.groupList:refresh()
end

function GroupStageViewLogic:onClose()
	if self.stageList then 
		self.stageList:destroy()
		self.stageList = nil
	end
	if self.groupList then 
		self.groupList:destroy()
		self.groupList = nil
	end
	GroupStageData.isViewOpen = false
	_instance = nil
end

local function onItemUpdate(self)
	self:updateInfo()
end
-- 
local function evt_StageTeamDataUpdate(self)
	self:showStageList()
end

local function evt_StageTeamListUpdate(self, pkg)
	if pkg.idstage == self.curStageID then 
		self:showGroupList(pkg.teamlist)
	end
end

local function evt_StageTeamListRefresh(self)
	if self.curStageID then 
		GroupStageData.requestStageTeamList(self.curStageID)
	end
end
local function onStageTeamCountUpdate(self)
	self:updateInfo()
end

function GroupStageViewLogic:initEventListener()
	self:registerEventListener(EventType.BagListRefresh, onItemUpdate)
	self:registerEventListener(EventType.StageTeamDataUpdate, evt_StageTeamDataUpdate)
	self:registerEventListener(EventType.StageTeamListUpdate, evt_StageTeamListUpdate)
	self:registerEventListener(EventType.StageTeamListRefresh, evt_StageTeamListRefresh)
	self:registerEventListener(EventType.StageTeamCountUpdate, onStageTeamCountUpdate)
end
