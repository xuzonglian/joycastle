
--组队副本 创建队伍
GroupStageCreateTeamViewLogic = class("GroupStageCreateTeamViewLogic",ViewBaseLogic)
-------------------------------------------------------
-- editType 1:创建队伍、2:修改队伍
function GroupStageCreateTeamViewLogic:ctor(editType, defaultStageID)
	self.CCS_FILE_NAME_PREFIX = Config.CSB_FILE_DIR_1
	self.csbName = "zuduifuben_chuangjianduiwu"
	self.fullScene = false
	self.viewLevel = SceneHelper.LAYER_TYPE.SECOND_LYAER

	self._editType = editType or 1
	if self._editType == 1 then -- 创建队伍
		self.curStageID = defaultStageID or 1
		self._teamType = 1
	else -- 编辑队伍
		local teamself = GroupStageData.teamself
		if teamself then 
			self.curStageID = teamself.idstage
			self._teamType = teamself.available
		else
			self.curStageID = defaultStageID or 1
			self._teamType = 1
		end
	end
end

function GroupStageCreateTeamViewLogic:onOpen()
	self:initUI()
end

function GroupStageCreateTeamViewLogic:initUI()
	self.Panel_1 = self:getView():getChildByName("Panel_1")
	self.Panel_2 = self:getView():getChildByName("Panel_2")

	self.btn_close = self.Panel_1:getChildByName("btn_close")
	self.txt_title = self.Panel_1:getChildByName("txt_title")
	self.txt_jichujiangli = self.Panel_1:getChildByName("txt_jichujiangli")
	-- self.img_exp = self.Panel_1:getChildByName("img_exp")
	-- self.txt_expValue = self.Panel_1:getChildByName("txt_expValue")
	self.img_gold = self.Panel_1:getChildByName("img_gold")
	self.txt_goldValue = self.Panel_1:getChildByName("txt_goldValue")
	self.CheckBox_shijiekejian = self.Panel_1:getChildByName("CheckBox_shijiekejian")
	self.txt_shijiekejian = self.Panel_1:getChildByName("txt_shijiekejian")
	self.CheckBox_juntuankejian = self.Panel_1:getChildByName("CheckBox_juntuankejian")
	self.txt_juntuankejian = self.Panel_1:getChildByName("txt_juntuankejian")
	self.txt_jilvhuode = self.Panel_1:getChildByName("txt_jilvhuode")
	self.btn_fubenxuanze = self.Panel_1:getChildByName("btn_fubenxuanze")
	self.txt_curStageName = self.btn_fubenxuanze:getChildByName("txt_curStageName")
	self.Node_item1 = self.Panel_1:getChildByName("Node_item1")
	self.Node_item2 = self.Panel_1:getChildByName("Node_item2")
	self.Node_item3 = self.Panel_1:getChildByName("Node_item3")
	self.btn_cancel = self.Panel_1:getChildByName("btn_cancel")
	self.btnTxt_cancel = self.btn_cancel:getChildByName("txt")
	self.btn_confirm = self.Panel_1:getChildByName("btn_confirm")
	self.btnTxt_confirm = self.btn_confirm:getChildByName("txt")

	self.Node_items = {self.Node_item1, self.Node_item2, self.Node_item3}
	self.rewardItems = {}

	self.Panel_click = self.Panel_2:getChildByName("Panel_click")
	self.Panel_stageList = self.Panel_2:getChildByName("Panel_stageList")
	self.Panel_2:setVisible(false)

	Util.setTextString(self.btnTxt_cancel, LanUtil.getLan("GroupStageTxt_10"))
	Util.setTextString(self.txt_jichujiangli, LanUtil.getLan("GroupStageTxt_11"))
	Util.setTextString(self.txt_jilvhuode, LanUtil.getLan("GroupStageTxt_12"))
	Util.setTextString(self.txt_shijiekejian, LanUtil.getLan("GroupStageTxt_13"))
	Util.setTextString(self.txt_juntuankejian, LanUtil.getLan("GroupStageTxt_14"))
	if self._editType == 1 then -- 创建队伍
		Util.setTextString(self.txt_title, LanUtil.getLan("GroupStageTxt_15"))
		Util.setTextString(self.btnTxt_confirm, LanUtil.getLan("GroupStageTxt_16"))
	else -- 修改队伍
		Util.setTextString(self.txt_title, LanUtil.getLan("GroupStageTxt_17"))
		Util.setTextString(self.btnTxt_confirm, LanUtil.getLan("GroupStageTxt_18"))
	end


	self.btn_close = self.Panel_1:getChildByName("btn_close")

	self:addClickEventListener(self.btn_close, function ()
		self:closeView()
	end)

	self.CheckBox_shijiekejian:addEventListener(function ()
		if self.CheckBox_shijiekejian:isSelected() then 
			self:setTeamType(1)
		else
			self:setTeamType(2)
		end
	end)
	self.CheckBox_juntuankejian:addEventListener(function ()
		-- log(string.format("isSelected:%s", tostring(self.CheckBox_xuanzhong:isSelected())))
		-- self:showExtraHanghaizhengEffect()
		if self.CheckBox_juntuankejian:isSelected() then 
			self:setTeamType(2)
		else
			self:setTeamType(1)
		end
	end)

	self:addClickEventListener(self.btn_fubenxuanze, function ()
		self:showStageList()
	end)

	self:addClickEventListener(self.Panel_click, function ()
		self.Panel_2:setVisible(false)
	end)

	self:addClickEventListener(self.btn_cancel, function ()
		self:closeView()
	end)

	self:addClickEventListener(self.btn_confirm, function ()
		if self._editType == 1 then -- 创建队伍
			GroupStageData.requestStageTeamCreate(self.curStageID, self._teamType)
		else -- 编辑队伍
			GroupStageData.requestStageTeamChange(self.curStageID, self._teamType)
		end
		self:closeView()
	end)
	self:setTeamType(self._teamType)
	self:updateInfo()
end

function GroupStageCreateTeamViewLogic:updateInfo()
	self:updateStageInfo()
end

-- 更新副本相关信息
function GroupStageCreateTeamViewLogic:updateStageInfo()
	local GroupStageDataTemplate = TemplateUtil.getData("GroupStageDataTemplate")
	local curStageCfg = GroupStageDataTemplate[self.curStageID]
	Util.setTextString(self.txt_curStageName, LanUtil.getLan(curStageCfg.name))
	-- Util.setTextString(self.txt_expValue, LanUtil.getLan(curStageCfg.exp))
	Util.setTextString(self.txt_goldValue, LanUtil.getLan(curStageCfg.gold))
	self:processRewardItem(1, curStageCfg.showItem1)
	self:processRewardItem(2, curStageCfg.showItem2)
	self:processRewardItem(3, curStageCfg.showItem3)
end

function GroupStageCreateTeamViewLogic:processRewardItem(index, itemInfo)
	local itemType = tonumber(itemInfo[1])
	local itemID = tonumber(itemInfo[2])
	local itemCount = tonumber(itemInfo[3] or 1) or 1
	local itemNode = self.rewardItems[index]
	if not itemNode then 
		itemNode = ItemNode.new()
		local itemLayer = self.Node_items[index]
		itemLayer:setScale(0.7)
		itemNode:openView(itemLayer)
		-- itemNode:getView():setPosition(posArr[i].x,posArr[i].y)
		RenderOptimizeManager.onSetGlobalZOrderRecur(itemNode:getView(), itemLayer:getGlobalZOrder())
		self.rewardItems[index] = itemNode
	end
	itemNode:UpdateInfo({type=itemType, item=itemID, count=itemCount})
	itemNode:setNameVisible(false)
	CSDTipTool.setItemTip(itemNode.imgBG, itemType, itemID)
end

-- 可见状态
function GroupStageCreateTeamViewLogic:setTeamType(_type)
	self._teamType = _type or 1
	if self._teamType == 1 then 
		self.CheckBox_shijiekejian:setSelected(true)
		self.CheckBox_juntuankejian:setSelected(false)
	else
		self.CheckBox_shijiekejian:setSelected(false)
		self.CheckBox_juntuankejian:setSelected(true)
	end
end

-- 显示关卡列表
function GroupStageCreateTeamViewLogic:showStageList()
	self.Panel_2:setVisible(true)
	RenderOptimizeManager.onSetGlobalZOrderRecur(self.Panel_2, self.Panel_1:getGlobalZOrder() + 200)

	local datalist = {}
	local GroupStageDataTemplate = TemplateUtil.getData("GroupStageDataTemplate")
	for k,v in pairs(ReadOnly.forPair(GroupStageDataTemplate)) do
		table.insert(datalist, v)
	end
	table.sort(datalist, function (a, b)
		return a.id < b.id
	end)

	if not self.stageList then
		local itemClass = require("com.hqfy.warship.modules.groupstage.GroupStageCreateTeamItem")
		local itemSize 		= cc.size(256, 85)
		self.stageList = TileListHelper.new({listLayer=self.Panel_stageList,itemSize=itemSize,
			gap=cc.size(0,9),cacheKey="GroupStageCreateTeamItem",itemCreateCallback=function( ... )
				return itemClass.new()
			end,initCallback=function(item,data)	
				item:setOwner(self)			
				item:UpdateInfo(data)
				if self.curStageID == data.id then 
					self:selectStage(item)
				end
			end, clickCallback=function(item)
				self:selectStage(item)
				self.Panel_2:setVisible(false)
				self:updateStageInfo()
			end})
		self.stageList:setTouchEnabled(true)
	end
	self.stageList:setDataProvider(datalist, false)
	self.stageList:refresh()
end

-- 选择关卡
function GroupStageCreateTeamViewLogic:selectStage(item)
	if self.curStageItem == item and self.curStageID == item.index and item._selected == true then  -- 不重复select
		return 
	end
	if self.curStageItem and not tolua.isnull(self.curStageItem) then 
		self.curStageItem:setSelected(false)
	end
	self.curStageID = item.index
	self.curStageItem = item
	self.curStageItem:setSelected(true)
end

function GroupStageCreateTeamViewLogic:onClose()
	if self.stageList then 
		self.stageList:destroy()
		self.stageList = nil
	end
	EventSystem.dispatchEvent(EventType.Event_Hide_Tip)
	for i,v in ipairs(self.rewardItems) do
		v:closeView()
	end
	self.rewardItems = {}
end

-- -- 战斗力变化
-- local function evt_LeagueDataUpdate(self)
-- end

-- function GroupStageCreateTeamViewLogic:initEventListener()
-- 	self:registerEventListener(EventType.LeagueDataUpdate, evt_LeagueDataUpdate)
-- end
