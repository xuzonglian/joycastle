
--组队副本 邀请入队
GroupStageInviteViewLogic = class("GroupStageInviteViewLogic",ViewBaseLogic)
-------------------------------------------------------
function GroupStageInviteViewLogic:ctor(idstage)
	self.CCS_FILE_NAME_PREFIX = Config.CSB_FILE_DIR_1
	self.csbName = "zuduifuben_yaoqingrudui"
	self.fullScene = false
	self.viewLevel = SceneHelper.LAYER_TYPE.SECOND_LYAER
	self._idstage = idstage
end

function GroupStageInviteViewLogic:onOpen()
	GroupStageData.requestStageTeamGuildMemberList(self._idstage)
	self:initUI()
end

local function tapClose(self)
	self:closeView()
end
local function tapExplain(self)
	ExplainViewLogic.new(63):openView()
end

function GroupStageInviteViewLogic:initUI()
	self.Panel_1 = self:getView():getChildByName("Panel_1")
	self.btn_close = self.Panel_1:getChildByName("btn_close")
	self.txt_title = self.Panel_1:getChildByName("txt_title")
	self.Panel_wanjialiebiao = self.Panel_1:getChildByName("Panel_wanjialiebiao")


	Util.setTextString(self.txt_title, LanUtil.getLan("GroupStageTxt_30"))

	self:addClickEventListener(self.btn_close, tapClose)

	self:updateGuildMemberList()

end

-- 显示军团玩家列表
function GroupStageInviteViewLogic:updateGuildMemberList(datalist)
	datalist = datalist or {}
	self.invitedList = {}

	if not self.memberList then
		local itemClass = require("com.hqfy.warship.modules.groupstage.GroupStageInviteItem")
		local itemSize 		= cc.size(401, 103)
		self.memberList = TileListHelper.new({listLayer=self.Panel_wanjialiebiao,itemSize=itemSize,
			gap=cc.size(0,9),cacheKey="GroupStageInviteItem",itemCreateCallback=function( ... )
				return itemClass.new()
			end,initCallback=function(item,data)	
				item:setOwner(self)	
				item:UpdateInfo(data)
			end})
		self.memberList:setTouchEnabled(true)
	end
	self.memberList:setDataProvider(datalist, false)
	self.memberList:refresh()
end

function GroupStageInviteViewLogic:onClose()
	if self.memberList then 
		self.memberList:destroy()
		self.memberList = nil
	end
end

-- 可邀请成员数据
local function evt_StageTeamGuildMemberList(self, pkg)
	self:updateGuildMemberList(pkg.memberlist)
end

function GroupStageInviteViewLogic:initEventListener()
	self:registerEventListener(EventType.StageTeamGuildMemberList, evt_StageTeamGuildMemberList)
end
