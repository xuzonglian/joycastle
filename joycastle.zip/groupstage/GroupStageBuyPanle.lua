


--
-- Author: Duke
-- Date: 2016-02-20 16:03:03
--
local GroupStageBuyPanle = class("GroupStageBuyPanle", ViewBaseLogic)

function GroupStageBuyPanle:ctor()
	self.CCS_FILE_NAME_PREFIX = Config.CSB_FILE_DIR_1
	self.csbName 		= "zuduifuben_goumai_node"
	self.fullScene 		= false
	self.clean 			= true
	self.viewLevel 		= SceneHelper.LAYER_TYPE.SECOND_LYAER
	self.count = 1
	self.limitCount = 0
end
 
function GroupStageBuyPanle:onOpen()
	self.count = 1
	self.buyCount = GroupStageData.countbuy
	local SpecConfigTemplate = TemplateUtil.getData("SpecConfigTemplate")
	self._maxBuyCount 	= SpecConfigTemplate[426].num
	self._buyCost 		= SpecConfigTemplate[427].num
	self.limitCount = self._maxBuyCount - self.buyCount

	self:_initUI()
end

function GroupStageBuyPanle:onClose()

end

function GroupStageBuyPanle:update()
	self.TextField_1:setString(self.count)
	self.img_gimTxt:setString(self._buyCost*self.count)
end

function GroupStageBuyPanle:_initUI()
	self.mask = self:getChildByName("img_mask")
	self:getChildByName("txt_title"):setString(LanUtil.getLan("jtboss_goumaicishu"))
	self:getChildByName("Text_1"):setString(LanUtil.getLan("txt_groupStageText_1"))
	self:getChildByName("Text_2"):setString(LanUtil.getLan("txt_groupStageText_2",self.limitCount))
	-- self:getChildByName("Text_2"):setString(self.limitCount)
	self:getChildByName("Button_close"):addClickEventListener(function()
		self:closeView()
		end)
	self.TextField_1 = self:getChildByName("TextField_1")
	self.TextField_1:setString(1)
	self.img_gim = self:getChildByName("img_gim")
	self.img_gimTxt = self.img_gim:getChildByName("txt")
	self.img_gimTxt:setString(self._buyCost)
	self.btn_buy = self:getChildByName("Button_sure")
	self.btn_buy:getChildByName("txt"):setString(LanUtil.getLan("TXT_BUY"))
	self.btn_buy:addClickEventListener(function()
		--次数用完后
		if self.limitCount == 0 then
			Global.showTips(LanUtil.getLan("socketError_67014"))
			return
		end
		if self._buyCost*self.count > PlayerData.cash then
			Global.showTips(LanUtil.getLan("eError_BUYTECH_NOCASH"))
			return
		end
		GroupStageData.requestStageTeamBuyCount(self.count)
		self:closeView()
		end)
	self.btn_reduce = self:getChildByName("btn_less")
	self.btn_reduce:getVirtualRenderer():getSprite():setGray(true)
	self.btn_reduce:setTouchEnabled(false)
	self.btn_reduce:addClickEventListener(function()
		self.count = self.count - 1
		self.btn_plus:getVirtualRenderer():getSprite():setGray(false)
		if self.count <= 1 then
			self.count = 1
			self.btn_reduce:getVirtualRenderer():getSprite():setGray(true)
			self.btn_reduce:setTouchEnabled(false)
		end
		self:update()
		end)
	self.btn_plus = self:getChildByName("btn_more")
	if self.limitCount <= 1 then
		self.btn_plus:getVirtualRenderer():getSprite():setGray(true)
		self.btn_plus:setTouchEnabled(false)
	end
	self.btn_plus:addClickEventListener(function()
		self.btn_reduce:setTouchEnabled(true)
		self.btn_reduce:getVirtualRenderer():getSprite():setGray(false)
		self.count = self.count + 1
		if self.count >= self.limitCount then
			self.count = self.limitCount
			self.btn_plus:getVirtualRenderer():getSprite():setGray(true)
			self.btn_plus:setTouchEnabled(false)
		end
		self:update()
		end)
end

-- function rfreshCount( ... )
-- 	-- self:getChildByName("Text_2"):setString(LanUtil.getLan("txt_groupStageText_2",self.limitCount))
-- end

return GroupStageBuyPanle